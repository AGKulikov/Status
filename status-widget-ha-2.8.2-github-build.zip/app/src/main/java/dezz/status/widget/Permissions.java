/*
 * Copyright © 2025-2026 Dezz (https://github.com/DezzK)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package dezz.status.widget;

import android.Manifest;
import android.app.AppOpsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class Permissions {
    private static final String[] REQUIRED_FOREGROUND_PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
    };

    public static boolean allPermissionsGranted(Context context) {
        return checkOverlayPermission(context)
                && checkForMissingForegroundPermissions(context).isEmpty()
                && isBackgroundLocationGranted(context);
    }

    public static List<String> checkForMissingForegroundPermissions(Context context) {
        List<String> missingPermissions = new ArrayList<>();

        for (String permission : REQUIRED_FOREGROUND_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }

        return missingPermissions;
    }

    public static boolean isBackgroundLocationGranted(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return true;
        }
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean checkOverlayPermission(Context context) {
        try {
            return Settings.canDrawOverlays(context);
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isNotificationAccessGranted(Context context) {
        try {
            String enabled = Settings.Secure.getString(context.getContentResolver(),
                    "enabled_notification_listeners");
            if (TextUtils.isEmpty(enabled)) {
                return false;
            }
            ComponentName component = new ComponentName(context, MediaNotificationListener.class);
            String flatten = component.flattenToString();
            for (String name : enabled.split(":")) {
                if (flatten.equals(name) || component.equals(ComponentName.unflattenFromString(name))) {
                    return true;
                }
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Whether the given {@code component} (flattened {@code <pkg>/<service-class>}) appears in
     * the system's enabled_accessibility_services list. Reading from {@code Settings.Secure}
     * is the standard way to check accessibility-service state without requiring
     * {@code BIND_ACCESSIBILITY_SERVICE} on the caller; both the framework and Google's own
     * samples use this approach.
     */
    public static boolean isAccessibilityServiceEnabled(Context context, String component) {
        try {
            String enabled = android.provider.Settings.Secure.getString(
                    context.getContentResolver(),
                    android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null || enabled.isEmpty()) return false;
            ComponentName target = ComponentName.unflattenFromString(component);
            for (String entry : enabled.split(":")) {
                if (entry == null) continue;
                String trimmed = entry.trim();
                if (trimmed.equals(component)) return true;
                ComponentName cn = ComponentName.unflattenFromString(trimmed);
                if (cn != null && cn.equals(target)) return true;
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isUsageAccessGranted(Context context) {
        // AppOpsManager.unsafeCheckOpNoThrow promises not to throw, but on some custom OEM ROMs
        // (MIUI/EMUI/Magic OS) it has been observed throwing SecurityException or returning a
        // null AppOpsManager. Guard everything.
        try {
            AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) {
                return false;
            }
            int mode;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        Process.myUid(), context.getPackageName());
            } else {
                mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        Process.myUid(), context.getPackageName());
            }
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }
}
