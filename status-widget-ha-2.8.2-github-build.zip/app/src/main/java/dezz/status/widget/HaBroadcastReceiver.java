package dezz.status.widget;
import android.content.*;
public class HaBroadcastReceiver extends BroadcastReceiver { public void onReceive(Context c,Intent i){String id=i.getStringExtra("brick_id");if(id==null||id.isBlank())id="default";if("ru.natro.statuswidget.HA_UPDATE".equals(i.getAction())){String t=i.getStringExtra("text");if(t==null)t=i.getStringExtra("state");HaBrickStore.update(c,id,t==null?"—":t);}else HaBrickStore.clear(c,i.hasExtra("brick_id")?id:null);if(WidgetService.isRunning())WidgetService.getInstance().applyPreferences();}}
