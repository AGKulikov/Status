package dezz.status.widget;
import org.json.*;
public final class HaBrick {
 public String id,name,text,fontFamily=Fonts.DEFAULT_KEY; public int fontSize=32,outlineAlpha=170,outlineWidth=2,contentAlpha=255,marginStart=4,marginEnd=4,adjustY=0; public boolean bold=false,italic=false,enabled=true;
 public HaBrick(String id){this.id=id;name=id;text="—";}
 public JSONObject toJson() throws JSONException{JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("text",text);o.put("fontFamily",fontFamily);o.put("fontSize",fontSize);o.put("outlineAlpha",outlineAlpha);o.put("outlineWidth",outlineWidth);o.put("contentAlpha",contentAlpha);o.put("marginStart",marginStart);o.put("marginEnd",marginEnd);o.put("adjustY",adjustY);o.put("bold",bold);o.put("italic",italic);o.put("enabled",enabled);return o;}
 public static HaBrick fromJson(JSONObject o){HaBrick b=new HaBrick(o.optString("id","ha"));b.name=o.optString("name",b.id);b.text=o.optString("text","—");b.fontFamily=o.optString("fontFamily",Fonts.DEFAULT_KEY);b.fontSize=o.optInt("fontSize",32);b.outlineAlpha=o.optInt("outlineAlpha",170);b.outlineWidth=o.optInt("outlineWidth",2);b.contentAlpha=o.optInt("contentAlpha",255);b.marginStart=o.optInt("marginStart",4);b.marginEnd=o.optInt("marginEnd",4);b.adjustY=o.optInt("adjustY",0);b.bold=o.optBoolean("bold",false);b.italic=o.optBoolean("italic",false);b.enabled=o.optBoolean("enabled",true);return b;}
}
