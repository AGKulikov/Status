package dezz.status.widget;
import android.content.*;import org.json.*;import java.util.*;
public final class HaBrickStore {
 private static SharedPreferences p(Context c){Context d=c.getApplicationContext().createDeviceProtectedStorageContext();return d.getSharedPreferences(c.getPackageName()+"_ha_bricks",Context.MODE_PRIVATE);}
 public static List<HaBrick> load(Context c){List<HaBrick> r=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString("items","[]"));for(int i=0;i<a.length();i++)r.add(HaBrick.fromJson(a.getJSONObject(i)));}catch(Exception ignored){}return r;}
 public static void save(Context c,List<HaBrick> l){JSONArray a=new JSONArray();try{for(HaBrick b:l)a.put(b.toJson());}catch(Exception ignored){}p(c).edit().putString("items",a.toString()).apply();}
 public static void update(Context c,String id,String text){List<HaBrick> l=load(c);HaBrick x=null;for(HaBrick b:l)if(b.id.equals(id)){x=b;break;}if(x==null){x=new HaBrick(id);l.add(x);}x.text=text;save(c,l);}
 public static void clear(Context c,String id){List<HaBrick> l=load(c);for(HaBrick b:l)if(id==null||id.equals(b.id))b.text="—";save(c,l);}
}
