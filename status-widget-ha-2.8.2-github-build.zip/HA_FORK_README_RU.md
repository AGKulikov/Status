# Status Widget HA — fork 2.8.2

Пакет: `ru.natro.statuswidget`. Устанавливается рядом с оригинальным Status Widget.

## Home Assistant

Добавьте основной блок **Home Assistant** в конструкторе. В его настройках нажмите **Настроить HA-кирпичики**. Внутри можно создать неограниченное число экземпляров.

Каждый экземпляр имеет независимые ID, название, текст, размер, обводку, прозрачность, отступы, смещение Y, жирность, курсив и видимость. Порядок меняется кнопками ↑/↓.

## Broadcast API

- package: `ru.natro.statuswidget`
- action update: `ru.natro.statuswidget.HA_UPDATE`
- extras: `brick_id`, `text`
- action clear: `ru.natro.statuswidget.HA_CLEAR`

```bash
am broadcast -a ru.natro.statuswidget.HA_UPDATE -p ru.natro.statuswidget --es brick_id gate --es text "Ворота закрыты"
```

## HA Companion

```yaml
action: notify.mobile_app_MONJARO
data:
  message: command_broadcast_intent
  data:
    intent_package_name: ru.natro.statuswidget
    intent_action: ru.natro.statuswidget.HA_UPDATE
    intent_extras: >-
      brick_id:gate,text:{% if is_state('cover.garage_gate','closed') %}Ворота закрыты{% else %}Ворота открыты{% endif %}
```
