# Natro — карта требований, исследований и открытых вопросов

- [24.11.2026 — FIELD3.5.6: пропадающая табличка, source gap и независимый handoff каждого экрана](NAVIGATOR_TURN_HANDOFF_2026_11_24_RU.md).
- [23.11.2026 — единый масштаб и границы таблички](NAVIGATOR_SIGN_VIEWPORT_2026_11_23_RU.md).

- [20.11.2026 — редкое моргание 3.5.4: гонка текстур и задержка GPU](NAVIGATOR_TURN_CAPTURE_RACE_2026_11_20_RU.md): воспроизведение production Java, кандидат 3.5.5; FIELD OPEN.

- [19.11.2026 — знак полос у поворота, видео мигания 3.5.2 и единое оформление двух вариантов таблички](NAVIGATOR_TURN_BALLOON_2026_11_19_RU.md).

- [19.11.2026 — правила «Недавних» ES Проводника, воспроизведение засорения списка 3.5.0 и проверки нового отбора в Natro 3.5.1](FILE_MANAGER_RECENTS_ES_RU.md).

- [06.11.2026: файловый менеджер, протокол Яндекс Диска и границы проверки](FILE_MANAGER_YANDEX_RU.md).

- [18.10: цепочка от запуска навигации до команды DIM](geely-kx11/research-2026-10-18-wings/NAV_LAUNCH_CHAIN_RU.md). STATIC: opcode14 предшествует Activity, getter читает Android Settings; дополнение20:03 — NaviInteraction обрабатывает callback7/data1 как разрешение, data2 как выход, отдельно от menu/data0. Дополнение20:08: проверены дополнительные consumers; AR renderer не найден, штатное меню переключает1/3, callback возможен от SettingsObserver. Дополнение20:11: проверены version/config/part-number кандидаты; паспорт внешнего DIM не найден. Получатель/renderer и независимое скрытие OPEN; QNX writeback не пассивный снимок.

- [18.10 FIELD3.3.2: same-boot switching и скрытый Sys2038](geely-kx11/research-2026-10-18-wings/FIELD_332_WINGS_RU.md). Первый положительный FIELD переключения; конкретное полноэкранное окно dimmenu отсутствует в visible composition. Renderer/hide OPEN.

- [18.10: системная пакетная проверка OEM-диалога, отдельный запуск приборки и повторные чтения OFF](geely-kx11/research-2026-10-18-wings/OEM_LAUNCH_332_RU.md). STATIC/SOURCE/replay; CI/APK ожидаются, FIELD и крылья OPEN.

- [18.10 FIELD3.3.1: OFF остановлен проверкой owner=UNKNOWN](geely-kx11/research-2026-10-18-wings/FIELD_331_CLOSE_UNKNOWN_RU.md). Activity закрылась, штатный DIM не восстановлен; точный parser input отсутствует.


- [18.10 после10:00: отменяемое закрытие приборки, ownership gate и DIM release](geely-kx11/research-2026-10-18-wings/SWITCH_CLOSE_FIX_RU.md). SOURCE/replay; OEM-диалог и FIELD остаются OPEN.

- [18.10 08:55/08:58: два wings ZIP, exit1 help и точные ветви меню mNavi/MConfig](geely-kx11/research-2026-10-18-wings/FIELD_0859_AND_SWITCHING_RU.md). SOURCE collector/replay; перенос активного приложения без остановки — обязательный эталон, точный handler и OEM-диалог OPEN. Нового APK нет.

- [18.10: адресная диагностика крыльев внутри Natro, кандидат3.3.0](releases/3.3.0/README_RU.md). SOURCE/replay; FIELD renderer/hide OPEN.

- [18.10: сверены73архива, вскрыты3KZB и843изображения, уточнены graphics/lock paths](geely-kx11/research-2026-10-18-wings/REPORT_RU.md). [Реестр SHA](geely-kx11/research-2026-10-18-wings/ARCHIVE_INVENTORY_RU.md), [план поиска renderer и адресный сбор](geely-kx11/research-2026-10-18-wings/NEXT_STEPS_RU.md). Полная семантика не заявляется; renderer/hide FIELD OPEN.

- [18.10: шесть входных SOME/IP callbacks, RVC consumer, MAX96755 getter и восстановление четырёх DSP tables](geely-kx11/research-2026-10-17-white-bar/QNX_DISPATCH_AND_DSP_20261018_RU.md). Уточнено происхождение счётчиков корпуса; renderer/независимый hide OPEN.

- [17.10 21:44: пробел section-only ELF анализа исправлен; 31 graphics candidate и новые конкретные ветви](geely-kx11/research-2026-10-17-white-bar/QNX_COVERAGE_2144_RU.md). Продолжать по уже полученному QNX, новый сбор сейчас не требуется; renderer/hide OPEN.

- [17.10, продолжение21:34: PA_Gauge reader → DA2B → sender callback; связи с оформлением не найдено](geely-kx11/research-2026-10-17-white-bar/PA_GAUGE_READER_2134_RU.md). Ограниченный STATIC, независимое скрытие OPEN.

- [17.10 21:16: два видео появления/исчезновения крыльев, раздельные фазы карты, фона и цифр](geely-kx11/research-2026-10-17-white-bar/WINGS_VIDEO_2116_RU.md). Связь с навигационной компоновкой усилена; renderer/hide OPEN.

- [17.10 20:53: FIELD3.2.9, завершённый сбор, четыре проблемных пути и растущий DIM-журнал](geely-kx11/research-2026-10-17-white-bar/FIELD_2053_RU.md).

- [17.10 19:11/19:15: MConfig/dimmenu restart, белая полоса, касания и результат докачки3.2.8](geely-kx11/research-2026-10-17-white-bar/FIELD_1911_1915_RU.md). [Исправления3.2.9](releases/3.2.9/README_RU.md).

- [Исправление досборщика3.2.8: QNX первым, изоляция optional snapshots](releases/3.2.8/README_RU.md).

- [17.10, FIELD3.2.7: ADB-срыв докачки,4772paths,10mappings и PA_Gauge](geely-kx11/research-2026-10-17-white-bar/DUMPS_327_857396_663180_RU.md).

- [17.10: полный архив578306, крылья и отрицательные результаты](geely-kx11/research-2026-10-17-white-bar/VEHICLE_578306_RU.md). [Native qconn links и докачка с977исключениями](geely-kx11/research-2026-10-17-white-bar/QCONN_LINKS_RU.md). FIELD новых путей OPEN.

- [17.10 16:15: updater Android9 — неверный certificate flag](releases/3.2.6/UPDATER_ANDROID9_RU.md): SOURCE3.2.6; реальный APK/API28 regression, CI/APK/FIELD OPEN. QNX16:22 снова RST/ACK до greeting, причина listener/reject OPEN.

- [3.2.5 опубликована stable/latest17.10 16:08МСК](releases/3.2.5/PUBLICATION_RU.md):2157 Android/264 tool/108 Java cases PASS, прежняя подпись; HUD уведомление, полный QNX/каналы и streaming download. FIELD OPEN.

- [17.10: HUD уведомление режима вождения — внешний вид MConfig48, прежний источник Natro](geely-kx11/research-2026-10-17-white-bar/HUD_DRIVE_MODE_RU.md): белая плашка/чёрный текст,3секунды; SOURCE, FIELD OPEN.
- [Полный архив QNX и сведения о каналах связи](geely-kx11/research-2026-10-17-white-bar/FULL_VEHICLE_ARCHIVE_RU.md): отдельный сбор с HU/телефона, потоковый ZIP и large download; FIELD OPEN.

- [17.10 повтор полосы: QNX доступен, mode3→1, regional owner correction и новые DIM targets](geely-kx11/research-2026-10-17-white-bar/WHITE_BAR_552935_RU.md). [MConfig48/46.1: прежнее скрытие и независимый стартовый сброс](geely-kx11/research-2026-10-17-white-bar/MCONFIG_48_COMPARISON_RU.md). Причинность/FIELD не закрыты; полный контент QNX ещё не снят.
- [17.10 после reboot:3193пути,33QNXфайла,13slog2,6wide mappings; actual libopenwfd mask stubs](geely-kx11/research-2026-10-16-qnx/DUMP_324_833791_RU.md). Сбор3.2.4 FIELD подтверждён в этом сеансе; крылья/полоса/причина отказа QNX OPEN. Пользователь уточнил перезагрузку до успешной пробы; promisc-причина не доказана.
- Stable [natro-v3.2.4](https://github.com/AGKulikov/Status/releases/tag/natro-v3.2.4) опубликован и проверен; прежние OPEN ниже — история этапов, не текущий статус публикации.

- [17.10: подписанная3.2.4, матрица и точные проверки](releases/3.2.4/README_RU.md) —2147 Android/260 tool tests PASS, стабильная подпись; KX11 FIELD OPEN. [Постоянный LAN, TXT/ZIP/дамп и канал](LAN_UPDATE_CHANNEL_RU.md); публикация stable проверяется отдельно.

Актуализировано17.10.2026. Это навигация по сохранённым знаниям проекта.
Дата этой страницы не означает повторной проверки всех прежних выводов на машине.

| Что нужно найти | Где читать |
|---|---|
| 17октября:812 путей QNX, ошибка stat `/proc`, повтор полосы и отсутствие battery warning | [FIELD и source patch,17tests; APK/FIELD OPEN](geely-kx11/research-2026-10-16-qnx/FIELD_20261017_STAT_AND_UI_RU.md) |
| Текущие пользовательские требования, изменения решений, критерии приёмки | [PROJECT_REQUIREMENTS_RU.md](../PROJECT_REQUIREMENTS_RU.md) — источник актуальных требований |
| Описание приложения и текущего выпуска | [README](../README.md), [3.2.4](releases/3.2.4/README_RU.md), [история3.2.3](releases/3.2.3/README_RU.md) |
| Архивное первоначальное ТЗ | [FORK_SPEC_RU.md](../FORK_SPEC_RU.md); при расхождении действует актуальный реестр |
| Найденные маршруты, адреса, параметры, проверки и ограничения Geely/ECARX | [Техническая база](../GEELY_KX11_KNOWLEDGE_RU.md), [индекс исследований](geely-kx11/README.md) |
| Что ещё неизвестно и какое свидетельство нужно следующим | [Очередь вопросов](geely-kx11/open_questions.json); записи имеют собственные даты и историю |
| Исследования прошивки и DIM12–14октября | [Архив разборов](geely-kx11/research-2026-10-12-13-archive/README_RU.md), [драйвер и MCU](geely-kx11/research-2026-10-13-dim/README_RU.md), [QNX init](geely-kx11/research-2026-10-14-dim/README_RU.md) |
| Предыдущий системный дамп3.2.2 | [Перенесённые выводы и гипотезы](geely-kx11/research-2026-10-16-qnx/DUMP_322_RU.md) |
| Первый FIELD3.2.3: QNX Connection refused, Android evidence и следующий шаг | [Разбор ZIP8283](geely-kx11/research-2026-10-16-qnx/DUMP_323_8283_RU.md) |
| Прямой nc-контроль: отказ также вне сборщика; следующий шаг — маршрут | [Фото терминала 17 октября](geely-kx11/research-2026-10-16-qnx/QNX_TERMINAL_20261017_RU.md) |
| Что изменено в сборщике3.2.3 и что предстоит проверить | [Полный доступный каталог QNX](geely-kx11/research-2026-10-16-qnx/FULL_INVENTORY_RU.md) |
| Белая полоса, VA и восстановление DIM | Реестр: записи04/07/10/14октября, DIM-WHITE-317; [обзор3.1.7](releases/3.1.7/SOURCE_REVIEW_RU.md). Причину OEM restart и физическую приёмку не считать закрытыми по одному CI |
| ANCS, батарея и свои иконки web app | Реестр: DIAG-313-WAL, BATTERY-EXACT-317, FIX-311-WEBICON; [архитектура ANCS](ANCS_V2_REFERENCE_ARCHITECTURE.md), [иконки](PHONE_NOTIFICATION_ICONS_RU.md) |
| Кнопки, медиа, старт карт | [Кнопки после обновления](BUTTON_UPDATE_RECOVERY_2026_10_03_RU.md), [медиа и карта](BUTTONS_MEDIA_MAP_2026_09_15_RU.md), [диагностика старта](MAP_STARTUP_DIAGNOSTICS_RU.md); актуальные отрицательные результаты — в реестре |
| Пассажирские окна и резервная копия | [HOME](PASSENGER_LAUNCHER_2026_10_03_RU.md), [панели](PASSENGER_PANEL_2026_10_03_RU.md), [backup contract](backup/FULL_BACKUP_CONTRACT_RU.md) |
| Маршрут с iPhone | [Опыт с историей Яндекса](ROUTE_HISTORY_DIAGNOSTIC_RU.md): история назначений не равна активному маршруту; готовый автоматический перенос не заявлен |

## Правило сохранения находок

Каждая существенная новая зацепка, пользовательская поправка, отрицательный
результат и следующий шаг фиксируются после исследования, без ожидания нового APK:

1. Подробный отчёт: дата; точный архив/файл и доступный SHA; версия/прошивка;
   метод; наблюдение; вывод и его границы; что опровергнуто; остаточный пробел.
2. Краткая актуальная запись в профильной базе и ссылка на отчёт.
3. Обновление текущего known/missing_evidence/next_step в очереди, если вопрос
   там представлен; прежний вывод сохраняется в истории.
4. Изменения требований и пользовательские поправки — в реестре в том же коммите.
5. Проверка удалённого commit и ссылок. Написанное только в чате или отдельном HTML
   не считается автоматически перенесённым в Git.

Отдельно отмечать: анализ кода/бинарника, наблюдение из конкретного дампа,
гипотеза, синтетическая проверка, проверка APK и физический результат на KX11.
Нельзя закрывать физическую проблему только по компиляции, совпадению имён
или наличию API. Опровергнутые предположения не удалять: сохранять причину,
область опровержения и ссылку на заменяющее свидетельство.

Сначала использовать уже сохранённые данные; повторный сбор нужен для
конкретного остаточного пробела. Публикуются наши выводы, источники и хэши,
не сырые приватные журналы, токены, ключи или чужие проприетарные исходники.

## Что проверено в этой актуализации

Сверены текущие Git-документы с сохранённым HTML-разбором3.2.2. Перенесены ранее
не отражённые в сводной базе результаты: два полных wfd_be mappings, четыре
ограниченных префикса, отсутствующие реальные библиотеки, mask stubs,
границы Android-композиции и slog2, отрицательные гипотезы и следующий сбор.
Связаны уже существующие исследования12–14октября и исправлен статус3.2.3.

Это не заявление о построчной сверке всех исторических разговоров и всех
веток проекта. Для остальных тем таблица указывает существующие материалы,
а не новую аппаратную проверку. В очереди сохранены все прежние вопросы.

## Дополнение17.10.2026: первичный дамп3.2.3

ZIP8283 проверен непосредственно:25entries/CRC,20manifest size/SHA.
QNX отказал до handshake; каталог/mappings остаются BLOCKED_TRANSPORT.
Сопоставлены исходники, предыдущий ZIP3.2.2 и Android HWC/window snapshots.
Обновлены база, реестр и очередь; добавлен QNX_ENDPOINT_ACCESS. Прежние54ID сохранены.

## Повторный FIELD3.2.3 DD605

[Повторный отказ после трёх минут и diff подключения](geely-kx11/research-2026-10-16-qnx/DUMP_323_DD605_RU.md).
Совет подождать2–3минуты проверен и не помог. Назначенный тогда контроль
прежней команды теперь выполнен: [такой же отказ в терминале](geely-kx11/research-2026-10-16-qnx/QNX_TERMINAL_20261017_RU.md).
Следующий шаг — текущий маршрут и запись соседа; первопричина OPEN.

## FIELD маршрута и таймаут терминала, 17.10.2026

[Дополнение IMG_8796/IMG_8797](geely-kx11/research-2026-10-16-qnx/QNX_TERMINAL_20261017_RU.md): маршрут совпал, eth0 neighbor REACHABLE. Natro отключает свою ADB-сессию по таймауту и может терять отображение накопленного вывода. Route/neigh выполнены; следующий шаг — ограниченный внешний timeout для nc, не повторение прежнего ожидания.

## Исправление ADB-PARTIAL-OUTPUT, SOURCE/TEST

[Реализация сохранения частичного вывода](geely-kx11/research-2026-10-16-qnx/QNX_TERMINAL_20261017_RU.md): 11/11 локальных тестов PASS. Нового APK и FIELD-приёмки пока нет; Connection refused остаётся открытым.

## FIELD QCONN, 17.10.2026 13:07 МСК

[Первичный архив проверки подключения](geely-kx11/research-2026-10-16-qnx/QNX_TERMINAL_20261017_RU.md): QCONN и FF FD22 получены. Следующий шаг — полный штатный системный сбор; причина прежнего отказа пока неизвестна.

- [17.10: полный QNX архив и другие каналы, SOURCE3.2.5](geely-kx11/research-2026-10-17-white-bar/FULL_VEHICLE_ARCHIVE_RU.md).

- [18.10: два корректных wings-сбора3.3.1, границы Android кадра и OFF](geely-kx11/research-2026-10-18-wings/FIELD_331_WINGS_RU.md).

- [18.10: публичная схема DIM≠DIS, Continental и ограничения идентификации](geely-kx11/research-2026-10-18-wings/WEB_DIM_IDENTITY_RU.md).

- [18.10: непрерывная запись DIM](geely-kx11/research-2026-10-18-wings/DIM_UART_RECORDING_RU.md): SOURCE/portable TEST; APK/FIELD OPEN.

- 20.10.2026: [UART19.10: шесть переходов, ACK/RX7, IHU-ready/обои](geely-kx11/research-2026-10-18-wings/UART_FIELD_2026_10_19_RU.md). Независимый hide OPEN.

- 23.10.2026: [XSF, stale-медиакнопки и traffic broadcast](geely-kx11/MEDIA_DELIVERY_2026_10_23_RU.md). SOURCE candidate, portable tests; APK/FIELD OPEN.

- 24.10.2026: [Серии/удержание MEDIA, исходные XSF edges и подтверждение маршрута](geely-kx11/MEDIA_GESTURES_2026_10_24_RU.md). STATIC/SOURCE,10 новых replay PASS; Android/APK/FIELD OPEN.

- 24.10.2026: [mNavi/наш Navigator: Алиса, ACK и возврат музыки](geely-kx11/ALICE_2026_10_24_RU.md). STATIC/SOURCE, TEST/APK/FIELD OPEN.

- 24.10.2026: [FIELD3.3.7: boot music и Navigator ANR](geely-kx11/BOOT_2026_10_24_RU.md). Команды отправлены, готовность не достигнута; bounded recovery SOURCE, FIELD OPEN.

- 25.10.2026: [FIELD Алисы3.3.8 и исправление Parcel](geely-kx11/ALICE_2026_10_25_RU.md).

- 06.11.2026: [Окончание голосовой сессии Алисы отдельно от закрытия окна](geely-kx11/ALICE_2026_11_06_RU.md). STATIC native FINISHED/IDLE и UI timer20s/7s; USER correction; SOURCE нового адаптера/TEST/APK/FIELD OPEN.

- [07.11.2026 — Алиса3.4.1 и автозапуск Музыки](geely-kx11/ALICE_MUSIC_2026_11_07_RU.md): FIELD отказ, SOURCE candidate, TEST/APK OPEN.


07.11.2026: [Navigator ANR/recovery candidate](../docs/geely-kx11/NAVIGATOR_ANR_2026_11_07_RU.md), branch fix/navigator-anr-20261107. SOURCE candidate; TEST/APK/FIELD OPEN; native root cause UNKNOWN.

- [07.11.2026 — FIELD3.4.3: ANR main stack, Music timeout/reservation](geely-kx11/BOOT_343_FIELD_2026_11_07_RU.md). Автозапуск FAILED; SOURCE анализ, исправление/APK OPEN.

07.11: [продолжение3.4.4 SOURCE](geely-kx11/BOOT_343_FIELD_2026_11_07_RU.md),8host Music replays PASS; Android/APK/FIELD pending.

- [FIELD3.4.4: два boot и Music endpoint_timeout](geely-kx11/BOOT_344_FIELD_2026_11_07_RU.md).

- [07.11.2026 — пересечение подготовки Music Natro 2 и PLAY](geely-kx11/MUSIC_PREPARE_PLAY_RACE_2026_11_07_RU.md): Natro3.4.5 SOURCE/TEST/APK PASS; Music2 совместима; FIELD нового порядка OPEN.


07.11.2026: [FIELD3.4.5 — Music timeout и native Navigator ANR](geely-kx11/BOOT_345_FIELD_2026_11_07_RU.md).
FIELD FAILED; candidate3.4.6/Music3, повторная аппаратная проверка OPEN.

- [12.11.2026: офлайн-волна и повторные PLAY](geely-kx11/MUSIC_OFFLINE_2026_11_12_RU.md) — SOURCE candidate, TEST pending, FIELD OPEN.

12.11 Music observation: SOURCE6db5fb18 / targeted CI43243646046 PASS; APK/FIELD OPEN.

MUSIC-WAVE-DIAG: native hook/observer implementation candidate; actual pinned DEX
patch and synthetic fixture checks PASS; release and physical capture OPEN.

- 20.11.2026: [мерцание при обновлении метров, масштаб и отдельные таблички](NAVIGATOR_TURN_BALLOON_2026_11_20_RU.md). SOURCE и целевой replay; полный CI/APK/FIELD отслеживаются в выпуске 3.5.4.

- 23.11.2026: [Масштаб и viewport табличек, CARD-026](NAVIGATOR_SIGN_VIEWPORT_2026_11_23_RU.md).

- 24.11.2026: [3.5.7 — передача видимости и опубликованные доказательства](releases/3.5.7/README_RU.md). SOURCE/TEST/APK/PUBLISH PASS; FIELD OPEN.

- 24.11.2026: [ревизия описания и требований](DOCUMENTATION_REVIEW_2026_11_24_RU.md), [действующие уточнения](CURRENT_REQUIREMENTS_RU.md). Полный структурный индекс; аппаратные gates не закрывались.
