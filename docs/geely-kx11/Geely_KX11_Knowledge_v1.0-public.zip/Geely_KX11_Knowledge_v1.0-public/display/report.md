# Приборка, HUD, дисплеи и мультимедиа Geely KX11 / ECARX

Дата повторного разбора: 2026-09-04. Область применимости — конкретная головная система из пользовательских дампов июля–сентября 2026 года. Идентификаторы и геометрия не объявляются универсальными для всех прошивок Geely. Ничего не отправлялось в автомобиль, APK не собирался.

## Что теперь установлено точнее

1. **HUD и Android-область приборки используют один displayId=2, но разные прямоугольники.** Display 2 имеет 1920×1080 и 30 Гц. Android-страница приборки при штатном режиме размещения занимает верхние 1920×720. Плоскость HUD в текущей реализации Natro — [0,720]–[728,910], то есть 728×190. Нельзя приравнивать весь displayId=2 к поверхности только одного устройства.
2. **Параметр `android.activity.SplitScreenShownPosition=0` действительно меняет доступную Activity геометрию.** Тест F даёт decor 1920×720; тест K3 без этого параметра даёт decor 1920×1080. Это подтверждено first layout, layout через 300/1000 мс и нулевыми insets. Это сильнее прежней догадки, что Android «всегда имеет только 720 пикселей». Но полноэкранный Activity сам по себе не подтверждает исчезновение штатных крыльев и может затронуть область HUD.
3. **Вывод, что остановка `com.ecarx.dimmenu` доказанно не влияет на крылья, прежним тестом не обоснован.** В тесте I ручная метка поступила после автоматического восстановления dimmenu. Тест загрязнён таймером. У теста J остановки HUD отсутствует синхронная ручная метка результата. Вопрос владельца крыльев остаётся открытым.
4. **Успешный возврат HUD API не равен смене физического HUD.** CB33278 возвращал SUCCEED и PA33937 менял dataValue, но availability был `invalid`; независимый PA_HUD_DispModSet продолжал показывать Active/IntellDrv. CB33284 также возвращал SUCCEED, а feedback33943 оставался 0.
5. **Найдены конкретные UI-зависания 8–9,8 секунды в Natro.** Два — fsync из синхронного SharedPreferences.commit при запуске HUD/приборки; третий — загрузка иконки в getView на main thread. Это не предположение о «медленной шине автомобиля».
6. **Текущая метрика `input→dispatch` не измеряет полную задержку кнопки руля.** Natro записывает input=SystemClock.uptimeMillis уже внутри Accessibility callback вместо event.getEventTime. Задержка до callback, включая заблокированный main looper, выпадает из измерения.

## Правила доказательности для этой подсистемы

| Уровень | Что означает | Чего не доказывает |
|---|---|---|
| Код / SDK | Символ, сигнатура или алгоритм существуют | Функция доступна на автомобиле |
| API accepted | Возврат SUCCEED/true или отправка Binder без исключения | Физическое действие завершилось |
| Подтверждённое чтение | Есть валидный feedback/Callback с изменением | Причину изменения без временной привязки |
| Подтверждённый UI | Activity создана на требуемом display, известны bounds/layout | Физически отображаемую QNX-композицию или отсутствие крыльев |
| Подтверждено на экране | Синхронная ручная метка/видео внутри изолированного воздействия | Эффект после перезагрузки, на другой прошивке |

`-1`, `notavailable`, `invalid`, null и значения-заглушки нельзя подменять состоянием OFF. Сырой `0` тоже требует проверки валидности и единиц. Пакет `com.ecarx.hud` — не вся физическая цепочка вывода HUD; наличие/отсутствие Android Activity не доказывает отключение проектора.

## Дисплеи и композиция

По dumpsys в HUD Lab 22:01, строки 2995–3037:

| local / display | Режим | Частота | Логическая density | Touch | Доказанная роль |
|---|---:|---:|---:|---|---|
| local:0 / 0 | 1920×720 | 60.000004 Гц | 160 dpi | INTERNAL | Основной Android экран; HUD Lab и launcher Activity видны здесь |
| local:1 / 1 | 1920×720 | 60.000004 Гц | 213 dpi | NONE | Отдельный HDMI-выход; физическую роль не выводить только из имени |
| local:2 / 2 | 1920×1080 | 30 Гц | 320 dpi | NONE | Совмещённая плоскость Android DIM/HUD, Presentation-capable |
| local:3 / 3 | 1920×720 | 60.000004 Гц | 160 dpi | EXTERNAL | Отдельный HDMI-экран; в дампе работает dd.monjaro.screensaver |

У display 2 FLAG_PRESENTATION, FLAG_OWN_CONTENT_ONLY, FLAG_SECURE, FLAG_SUPPORTS_PROTECTED_BUFFERS; в тестах также public flags=0xb и state=2/ON. `dumpsys display` для local:2 сообщает layerStack=2. Не выбирать дисплей по позиции в массиве `getDisplays()`: в Natro `HudDisplaySelector` выбирает точный id=2 и при его отсутствии ждёт. Не переносить найденные числовые IDs на неподтверждённую прошивку без проверки fingerprint и набора дисплеев.

`#2` в имени SurfaceFlinger слоя — часть имени/счётчик, а не достаточная привязка к display 2. Привязку доказывают поля layerStack, DisplayInfo и parent; отдельные выводы старых трасс содержат `Display Root#2` с layerStack=1. Поэтому имя слоя отдельно не является надёжным идентификатором физического выхода.

В базовом состоянии K3:

- `com.ecarx.hud/.hud.HomeActivity`: task bounds [0,720]–[728,906]. Это 728×186 task bounds; не смешивать с отдельным буфером HUD 728×190 или Natro safe plane 728×190.
- `com.ecarx.dimmenu/.MainActivity`: [728,720]–[1568,1032], freeform.
- Видны `ecarx_daemon_OverlayDisplay#0..4`, включая активную RGBA поверхность 1920×720 с очень высоким z. Наличие surface не устанавливает, какие её пиксели являются крыльями.
- Нативные безымянные слои, OEM overlay и Android task сосуществуют. Удаление одной Activity не позволяет объявить всю графику «нарисованной QNX».

Текущий `HudViewportPolicy.java` фиксирует: displayId=2, layerStack fallback=2, full surface1920×1080, editor1760×720, HUD safeLeft=0, safeTop=720, safeWidth=728, safeHeight=190. Это контракт текущего Natro, со ссылками в исходнике на mHUD6.1. Прямое поведение mHUD APK в этом подразделе отдельно не декомпилировалось.

## Запуск своей страницы на приборке

Сигнатуры подтверждены текущим Natro и последовательностями в оригинальных логах:

```java
DimInteraction.create(context).getDimMenuInteraction()
IDimMenuInteraction.switchNaviMode(int mode)
IDimMenuInteraction.getNaviMode()
DIMProtocolManager.getInstance(context)
DIMProtocolManager.sendMessageToDIM(byte, byte, byte, byte[])
ActivityOptions.makeBasic().setLaunchDisplayId(2)
```

Имя первого класса — `com.ecarx.xui.adaptapi.diminteraction.DimInteraction`; менеджера протокола — `ecarx.dimprotocol.DIMProtocolManager`. Natro вызывает их reflection. Сами названия DIM, opcode, service/field в обозначении `(2,8,8,[1])` не следует расширять до выдуманного описания транспорта без исходника SDK.

| Воздействие | Параметры | Подтверждение | Ограничение |
|---|---|---|---|
| Навигационный режим DIM | switchNaviMode(3) | true, затем getNaviMode=3 | Это режим DIM, не HUD ProfileTransfer mode3 |
| Режим DIM2 | switchNaviMode(2) после запуска F | true, readback=2 в H | Визуальное значение режима не определено этим логом |
| Возврат DIM | switchNaviMode(1) | true | Независим от закрытия/остановки Activity |
| Протокольное пробуждение | sendMessageToDIM(2,8,8,new byte[]{1}) | OK в тестах | Нет отдельного ACK физического DIM |
| Тестовый возврат протокола | (2,8,8,[0]) | OK | В MConfig0.103 для ветви возврата используется [1]; это разные реализации, не единый универсальный рецепт |
| Запуск Activity | MAIN + NEW_TASK + display2 + windowingMode5 + SplitScreenShownPosition0 | onCreate/onResume, decor1920×720 | Проверен на отдельном пакете ClusterProbe |
| K3 без SplitScreenShownPosition | Остальная подготовка F сохранена | onCreate, decor1920×1080; NaviMode3 | Ручного визуального результата о крыльях нет |

Историческая работающая последовательность F в HUD Lab: mode3 → ожидаемая пауза100мс → DIM[1] → ожидаемая пауза200мс → три force-stop **только тестового пакета** с паузами50мс → новый task. Это описание проведённого теста, не рекомендация трижды force-stop Natro или заводские приложения. Реальные интервалы логов больше заданных пауз из-за исполнения и диагностики. Ни necessity трёх остановок, ни оптимальность пауз не доказаны A/B-сравнением.

В MConfig0.103 `KeysConfigReceiver.kt:156–220` после mode3 и DIM[1] отправляет явный broadcast `action.RESTART` пакету `ru.monjaro.helper` с extras `packageName`, `packageActivity`, `displayId=2`. Другая ветвь отправляет `action.START`. Разделять внешнего владельца перезапуска и само перезапускаемое приложение: приложение не может надёжно продолжить свою цепочку после собственного force-stop.

В Natro HEAD `InstrumentDisplayLauncher` есть последовательная очередь `instrument-dim-launch`, паузы100/200мс, до10 попыток появления display через1500мс, запуск NavigationHudEndpointService перед handoff. Это реализация HEAD, не доказательство, что она присутствовала в APK из более раннего лога. При доставке необходимо хранить и сравнивать commit/version установленного APK.

## Пересмотр неудачных исследований крыльев

| Тест / источник | Что реально произошло | Корректный вывод |
|---|---|---|
| 07:53 / HUD Lab0.31 | Foreground fallback заявил LAUNCH API OK; нет подтверждения жизненного цикла целевой Activity | API OK недостаточно. Позднейший лог указывает PSD MessageDialog как перехватчик |
| 18:08 / 0.32 D | Служба запуска не подключена; LAUNCH НЕ ОТПРАВЛЕН | Это не проверка успешного запуска на DIM |
| 18:21 / 0.32 D | Accessibility Context отправил запрос; за3с нет onCreate/onResume | Смена режима3 сама по себе не гарантирует создание Activity |
| 19:14 / F | Отдельный ClusterProbe успешно создан display2/decor1920×720; ручная метка «крылья видны» внутри теста | Появление своей Activity и режим3 не убирают крылья в этой конфигурации |
| 21:30 / H | После F mode2 true/readback2, затем mode3 readback3; Activity сохранена | Управление режимом работает; визуальный эффект на крылья не задокументирован |
| 22:01 / I | dimmenu остановлен22:02:09.612, отсутствие процесса доказано22:02:12.031; восстановление22:02:16.555; ручная метка22:02:18.135 | Метка относится уже к восстановленному состоянию. Нельзя заключать, что крылья не принадлежали dimmenu |
| 22:27 / J | com.ecarx.hud остановлен, отсутствует в snapshots; восстановлен boot receiver, HUD_RESTORE_CONFIRMED | Остановка/восстановление приложения подтверждены. Нет ручного/видео результата по трём отдельным объектам: крылья, машинка, проекция |
| 22:44 / K3 | Без SplitScreenShownPosition Activity1920×1080, insets0, NaviMode3 | Подтверждена большая Android геометрия. Скрытие OEM графики не подтверждено |

Следующее корректное исследование: воспроизвести один тест на стоящей машине, заранее зафиксировать исходный режим и состояние поверхностей, собрать синхронное видео, поставить ручную метку до восстановления, фиксировать фактическое время каждого изменения. Не повторять широкий перебор DIM/HUD полей как замену изолированному тесту.

## Штатные HUD режимы и выбор содержимого

`hudlab-runtime.txt` из `ecarx-hud-system-20260727-010640.zip` — самостоятельный первичный runtime источник, 123 строки, прочитан полностью.

| Интерфейс / ID | Значения / ответ | Уровень знания |
|---|---|---|
| ProfileTransfer `CB_HudDispModSetgReq` CB33278; `getPA_HudDispModSetgReq` PA33937 | 0 IntellGude (в подписи теста IntellGuide),1 IntellDrv,2 AR,3 Simple | Все4 команды SUCCEED, dataValue меняется; availability=invalid. Реальный HUD эффект не доказан |
| Независимый `PA_HUD_DispModSet` | availability=Active,dataValue=IntellDrv | Валидное чтение; не совпадает с выбранным AR в другом PA |
| `HUD_ACTIVE` 0x20110100 | support=active,value1,allowed[1,0] | Функция и допустимые значения подтверждены чтением |
| `HUD_AR_ENGINE` 0x27020200 | notavailable,value0,allowed[1,0] | Недоступно на этом снимке, наличие allowed не отменяет notavailable |
| SAFETY 0x27030100 | notavailable,value255,allowed=null | Не подтверждённый write path |
| MEDIA 0x27030200 | то же | Не считать настройкой, работающей на KX11 |
| NAVI 0x27030300 | то же | Не считать выключателем оригинальной навигации |
| BTPHONE 0x27030400 | то же | Не считать выключателем звонков |
| DRIVE_ENVIRONMENT 0x27030500 | то же | Не считать способом убрать машинку/крылья |
| Vehicle model clear CB33284 / PA33943 | SUCCEED для ON/OFF; feedback33943=0 | Нет подтверждённого изменения состояния |
| DIM information mode signal30792 | 0..3, SUCCEED | API accepted; feedback/визуальная семантика не установлены |
| Individual DIM theme signal30785 | ON/OFF, SUCCEED | API accepted; эффект не установлен |
| Visual mask signal30816 / VHAL0x21707860 | Тест посылал20 полей F00..F19 и PEN15 | Записанный TX, не доказанная маска отображения |

Profile/PEN противоречие: UI показывал `Active profile / PEN:13 / ERROR PEN=-1`, ожидал валидный PEN1..13, затем тест использовал локальное PEN15. Нельзя переносить15 как универсальный active-profile ID. Прежде чем интерпретировать visual mask, необходимо установить реальное назначение PEN, валидность соответствующего PA и адресуемого профиля. Из логов не следует, что PEN15 — разрешённый broadcast profile.

В старых трассах вспомогательный reader возвращал `CarNotConnectedException: Invalid property Id:0x70d2` для NetIHU28882, `-1` для NetDIM30937/30938, остальных priority/resource; DIM NaviMode отдельного reader — `не подключён`, хотя команда и отдельный readback срабатывали. Значит reader и управляющий объект имели разную готовность; эти `-1` не доказывают отсутствие соответствующего автомобильного сигнала.

## Собственная HUD Surface Natro

Текущая реализация состоит из обычного WindowManager fallback и отдельного `app_process` владельца SurfaceControl (`HudSurfaceBridgeMain`). В исходнике явно предусмотрено: fallback остаётся до ACK первого полного кадра; при потере bridge можно восстановить обычное окно. Это локальный UI-механизм, не управление автомобилем.

В bridge: unparented SurfaceControl, PixelFormat.TRANSLUCENT, initial HIDDEN0x4, setOpaque(false), setLayerStack выбранного display, z=Integer.MAX_VALUE−1, setPosition(left,top), crop(0,0,width,height). Перед кадром Canvas очищается CLEAR. Плоскость ограничена728×190 на(0,720). Получатель принимает соединение только loopback, nonce и готовый размер; MAX_FRAME_BYTES4MiB, accept15с, frame timeout5с. Клиент имеет double-buffer/coalescing последнего кадра и отдельную I/O очередь. У этих констант нет отношения к CAN IDs.

Важно: разрешение SurfaceControl 1920×1080 для теста K3 не даёт основания растянуть рабочую HUD Surface до всего дисплея. Это затронет зоны, не принадлежащие HUD. Дочерние SDK View, системные overlays и прямой SurfaceControl имеют разные z-order/permission/lifecycle модели.

## Телеметрия: быстрый путь без очереди устаревших кадров

Числовые sensor IDs из повторно извлечённого SDK (`priority_constants.json`, отдельный каталог прошивки): speed `0x100100` /1048832; speed_from_IPK `0x101a00` /1055232; rpm `0x100900` /1050880; gear `0x200200` /2097664; odometer `0x100700` /1050368; fuel_level `0x100600` /1050112; total range `0x100800` /1050624; fuel range `0x101800` /1054720; coolant temperature `0x100f00` /1052416; ambient `0x100b00` /1051392; indoor `0x100c00` /1051648; EV battery `0x100a00` /1051136. Это ISensor IDs, их нельзя подставлять вместо PA/CB IDs либо VHAL property IDs. Полная машиночитаемая выборка HUD/ISensor — `display_sensor_sdk_constants.json`.

Дополнительные HUD SDK поля: brightness `0x27010100`, min/max/step `0x27010300`/`0x27010200`/`0x27010400`, brightness adjust `0x27010500`, position adjust `0x27010600`, angle adjust/reset `0x27010700`/`0x27010800`, snow mode `0x27020100`, calibration `0x20110200`. Диапазоны, единицы и runtime support в этих новых полях здесь не установлены: их наличие в SDK не делает функции проверенными переключателями. Точное имя SDK для media содержит опечатку `SETTING_FUNC_HUD_DISPLAY_MEIDA`.

`InstrumentTelemetryRepository` в HEAD — один общий процессный singleton с union-demand видимых panel/editor owners. Он подписывает только необходимые метрики через `CarIntegration.subscribeRealtimeTelemetry`, держит volatile primitives и будит соответствующих UI owners; при последнем release снимает подписки. Источник `GeelyCarIntegration` создаёт ISensor.ISensorListener с `onSensorValueChanged(type,float)`, `onSensorEventChanged(type,int)`, `onSensorSupportChanged(type,status)`. На callback он выдаёт observedAt=`elapsedRealtimeNanos`, без main-looper hop; это время получения, не время измерения ECU.

Обычный telemetry путь и realtime путь в GeelyCarIntegration сосуществуют. Singleton InstrumentTelemetryRepository гарантирует одну demand-сессию среди своих клиентов, **не одну-единственную vendor подписку для всей программы**. Нельзя утверждать, что уже устранены все дубли, если отдельные HUD/плитки подписываются обычным API. Удалять listener следует с того же manager, на котором его регистрировали; binder death требует повторного связывания и восстановления по фактическому demand.

Поддерживаемые текущим repository metric IDs: ISensor.speed, rpm, gear, odometer, fuel_level, range_fuel, range_total, ambient_temp, indoor_temp, coolant_temp, ev_battery_level, instant_fuel_consumption, avg_fuel_consumption, avg_fuel_consumption_ignition. Их названия — ключи Natro, не wire IDs и не доказательство доступности всех датчиков двигателя/EV на данном авто.

Рекомендация по архитектуре: один источник и кэш для каждой метрики; быстрые speed/rpm/gear доставлять без ожидающего FIFO старых кадров, UI читать последний snapshot на VSync; медленные значения обновлять по callback. Не просить повышенный rate для всех полей без измерения. Display2 физически30Гц, поэтому нельзя обещать60 уникальных показанных кадров/с только изменением Android renderer.

## Кнопки руля и маршрутизация музыки

### Реально найденные входы

В MConfig0.103 `KeysConfigReceiver.kt` присутствуют следующие **точные** действия:

| Action | Payload / ветка | Что известно |
|---|---|---|
| `android.intent.action.IEDIA_BUTTON` | Parcelable KeyEvent в `android.intent.extra.KEY_EVENT` | Именно IEDIA в исходнике. Перенаправляется в AudioManager или стандартный MEDIA_BUTTON |
| `android.intent.action.MEDIA_BUTTON` | Тот же KeyEvent | Стандартный media broadcast, принимается с учётом SRC_mode_default |
| `ecarx.intent.action.ECARX_KEY_RSRC_EVENT_DOWN/UP` | Нажатие/отпускание SRC | Обрабатываются если включён SRC remap |
| `ecarx.intent.action.ECARX_KEY_ISRC_EVENT_DOWN/UP` | Альтернативный SRC вход | В том же receiver |
| `ecarx.intent.action.ECARX_KEY_RSRC_EVENT` | Extra `ecarx.extra.ECARX_KEY_EVENT_TYPE` = KEYCODE_R_SRC | Legacy/rebroadcast путь |
| `ecarx.intent.action.ECARX_KEY_ISRC_EVENT` | Legacy input | Может rebroadcast в RSRC |
| `ecarx.intent.action.vr_pressed` / `vr_released` | Voice assist press/release | Отдельная логика одиночных/двойных/долгих |

Это доказательство кода стороннего референса. Не доказано, что каждая ветвь уже приходит в Natro на текущей конфигурации. Нужна запись фактического receiver/key callback без смешения с `ECARX_ADAS_SIGNAL_CHANGE`: source=`steering_key` в research logs использовался для общей разведки сотен свойств, а не только физических кнопок.

В MConfig deliberate delay: обычный SRC/VA single/double/triple ждёт900мс после отпускания, long1400мс, блок после некоторых действий500мс; legacy single SRC ждёт1200мс. Обычные next/previous KeyEvent в media ветви пересылаются сразу. Поэтому нельзя объяснять задержку next/previous цифрой900мс из SRC-кода.

### Текущий Natro

`WidgetAccessibilityService.onKeyEvent` поддерживает MEDIA_NEXT, MEDIA_PREVIOUS, MEDIA_PLAY, MEDIA_PAUSE, MEDIA_PLAY_PAUSE, HEADSETHOOK. На первом ACTION_DOWN передаёт команду cached `SteeringMediaKeyRouter`, повторные DOWN не повторяют команду, соответствующий UP поглощается только если DOWN был обработан. Если маршрут не готов или возник RuntimeException — возвращает false/штатная обработка, не делает широкую рассылку самостоятельно.

Маршрутизатор заранее выбирает MediaController с учётом закреплённого package, слушает active sessions, хранит volatile route. Отдельный `steering-media-route` looper используется для выбора. Сам dispatch вызывает один TransportControls: skipToNext/skipToPrevious/play/pause. Вызов без исключения записывается как `accepted`; Android TransportControls не даёт здесь подтверждения начала звука. OnPlaybackStateChanged и OnMetadataChanged — отдельные callbacks на **main** Handler. Частоты этих callbacks не считать скоростью исполнения команды руля.

Дополнительный риск из исходника: callback состояния плеера и AccessibilityService работают через main. Даже если Binder dispatch не ищет сессию и не ждёт запуска приложений, блокировка main задерживает вход в обработчик и обновление cached playbackState. Это может влиять и на toggle play/pause.

### Доказанные зависания и пределы измерений

Latest source log `status-widget-debug(20260904-172755).txt`:

| Время | Watchdog | Стек main | Вывод |
|---|---:|---|---|
| 2026-09-03 17:17:46.793 | 9432мс | FileDescriptor.sync → SharedPreferences.Editor.commit → HudModeFallbackBootReceiver.onReceive:48 | Main занят синхронным сохранением на диск |
| 2026-09-04 08:07:21.306 | 8002мс | FileDescriptor.sync → commit → InstrumentPanelStore.issueLaunchToken:129 → InstrumentDisplayLauncher.startPanel:125 | Запуск приборки может блокировать UI до открытия |
| 2026-09-04 19:38:53.267 | 9830мс | nativeOpenXmlAsset → VectorDrawable/AdaptiveIconDrawable → HighResolutionAppIconLoader → DriverPanelOverlayController.AppsAdapter.getView:1930 | Иконки грузятся на UI в момент прокрутки |

У третьего события steering-media-route находится в MessageQueue.nativePollOnce; это не свидетельство забитой очереди resolver. Фоновый поток ожидания не исправляет main, на который придёт Accessibility callback.

В просмотренном журнале есть selected/destroyed/playback_callback/metadata_callback для ru.yandex.music, но отсутствуют строки dispatch с input/key. Следовательно, нельзя вычислить p95 задержки или доказать, что эти stalls совпали с конкретным нажатием кнопки. Текущее `inputUptimeMs` формируется вызовом SystemClock.uptimeMillis внутри onKeyEvent; требуется дополнительно записывать event.getEventTime(), getDownTime(), callback-entry uptime, dispatch begin/end, event action/repeat, session token/package и first matching playback/metadata callback. Не хранить один timestamp под названием «время кнопки» для всех границ.

## Неизвестные функции: конкретный следующий шаг

| Пробел | Уже известно | Чего не хватает / следующий минимальный шаг |
|---|---|---|
| Владение крыльями и серой машинкой | F их не убирает; K3 увеличивает Android-area; существуют OEM/native layers | Видеопривязка к I/J/K3, маркер до restore; owner/buffer pixel attribution |
| Реальные эффекты NaviMode1/2/3 | Управление/чтение подтверждены | Снимки физических DIM/HUD отдельно на стабильном Activity/task |
| HUD ProfileTransfer0..3 | CB accepted/data echo | Независимый валидный статус, физическое изображение, сохранение после sleep/boot |
| PEN/profile masks | Есть signal30816 и protobuf fields; reader PEN=-1 | Валидный активный профиль и декодирование profile exchange; не подставлять15 |
| Selective HUD content | SDK symbols существуют, runtime notavailable | Поддержка в точной прошивке/другой штатный call path; до этого не показывать как рабочие переключатели |
| Высокая задержка руля | Cached direct dispatch есть; UI stalls доказаны | Сопоставить hardware event time→callback→Binder→player→audio; измерить p50/p95 и maxima |
| Быстрота телеметрии | Есть realtime callbacks и demand-union | Межприходовые интервалы, единицы/raw/scale, end-to-end latency, число активных vendor subscriptions |
| Системная шторка | В слоях CSD.ShadeBg, PSD.ShadeBg и CarNavigationBar | Владельцы IPC/gesture trigger и OEM suppress API; имён Surface недостаточно для безопасной замены |

## Где искать доказательства

Полные восемь `hudlab-cluster-*.txt` в конце исследования получены в `research/shared`; критические номера строк проверены на оригинальных байтах и совпадают с Library read. SHA256 и полные локальные пути находятся в `sources.json`. Ключевые точки: K3 geometry строки585–674; F22:27 geometry551–640; I stop2986–2989, restore3991–3996, поздняя метка4698–4701; J stop2841–2842, snapshot отсутствия2869–2874, восстановление4996–5004.

Важное предупреждение версионирования: параллельный разбор нашёл различающиеся числовые CB/PA константы между системным SDK и SDK, встроенным в `com.ecarx.dimmenu/base.apk`. Числа в этом тексте для CB33278/PA33937 — ровно числа наблюдавшегося runtime теста и текущего Natro. Перед новым внедрением сверить системные классы и `firmware_catalog/conflicts.json`; нельзя подменять их одноимённым полем из произвольного встроенного SDK.

- `evidence_reads.json` содержит сохранённые Library read/find результаты с исходными номерами строк. Файлы `*.first1000.txt` — только первые1000стр каждого лога, специально переименованы, чтобы не выдавать их за полные оригиналы.
- `repo/*.java` — исходники Natro из GitHub `AGKulikov/Status`, commit `c3f83a07af7f5a81ec39a8df7bc29bc71f80aef8`; это не гарантия соответствия установленному APK.
- `watchdog_*.txt` — окна оригинального latest debug log; номера в имени соответствуют начальной строке исходного файла.
- Реальный `hudlab-runtime.txt` взят из архива ECARX27.07. MConfig0.103 — отдельный исходный референс, его версию не смешивать с MConfig+v45.
- `sources.json` фиксирует Library IDs/пути, диапазоны и GitHub URLs для повторного аудита.
