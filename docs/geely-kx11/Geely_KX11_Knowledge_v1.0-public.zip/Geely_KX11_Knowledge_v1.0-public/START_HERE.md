# Начало работы с базой Geely KX11 / ECARX

Публичная редакция: сначала учесть состав и ограничения в `PUBLIC_EDITION.md`.

Сначала прочитать `Geely_KX11_ECARX_Engineering_Guide_v1.0.md`. Это зафиксированная база знаний на 2026-09-04, а не исполняемый профиль автомобиля.

## Поиск

`python3 tools/lookup.py PAC_ACTIVATION` ищет ID, название или функцию в статическом SDK, клиентских действиях и журналах. Можно искать `климат`, `0x23030100`, `AsyALgtIndcr`, `Cruise`, `ReadLight`, `mirror`, `HUD`. Поиск идёт локально, сетевых соединений и отправки команд нет. Полные поля лежат в соответствующем JSON; команда печатает компактные карточки и пути к данным.

## Каталоги

- `firmware/catalog.json`: AdaptAPI, CarSignal, manager ID, точный bridge SDK→VHAL, native access/type. Статическая декларация не означает поддержку на автомобиле.
- `firmware/conflicts.json`: одинаковые имена с различными значениями в системном и встроенных SDK. Проверять до выбора ID.
- `firmware/constants.json`, `firmware/sdk_to_hal.json`, `firmware/native/vhal_properties.json`: подробные словари, преобразования и конфигурации с исходными адресами/хэшами.
- `controls/natro_controls.json`: конечные определения функций Natro; `controls/mconfig_actions.json`: реально найденные вызовы MConfig v45. Они не являются allowlist для выполнения.
- `observations/observed_signals.json`: 14 отдельных экспортов и числовые наблюдения; `camera_gear_transitions.json`: выбранные переходы camera/PAS/gear.
- `cruise/`: доказательства отрицательной native-ветви, PCAP и структуры QNX bridge.
- `display/`: интерфейсы дисплеев/мультимедиа, привязки к исходным строкам и SDK.
- `provenance/`: исходные имена/идентификаторы, SHA-256, ZIP-member inventory и глубина проверки.
- `open_questions.json`: текущие пробелы с необходимым доказательством и следующим шагом.

## Обязательное различение

Для каждой будущей функции заполнить:

```json
{
  "firmware_fingerprint": null,
  "namespace": null,
  "runtime_class_origin": null,
  "id": null,
  "zone": null,
  "type": null,
  "units": null,
  "allowed_values": null,
  "sdk_present": null,
  "native_access": null,
  "runtime_support": "unverified",
  "request_semantics": "unknown: set/toggle/pulse",
  "request_accepted": null,
  "feedback_changed": null,
  "physical_effect_verified": null,
  "source": {"file": null, "sha256": null, "locator": null}
}
```

`null` означает отсутствие доказательства, а не ноль. Не заполнять неизвестные поля из похожей модели автомобиля. Generic SET retry допустим только после установления idempotent семантики конкретной функции. Чтение `/proc/net/can/reset_stats` исключено: в корпусе доказан побочный эффект сброса статистики.

Подтверждённые отрицательные результаты не повторять тем же инструментом без новой гипотезы. Перед новой выгрузкой сформулировать точный отсутствующий файл/поле/пакет. Не просить пользователя заново отдавать уже перечисленные источники, пока они доступны по реестру. Прежние ограничения на сборку APK и публикацию исходников проверять по текущему поручению; создание этой базы не является новой командой сборки или отправки в GitHub.

## Воспроизведение локального анализа

```sh
python3 tools/analyze_action_logs.py /path/to/action-exports /path/to/output
python3 tools/audit_trace_archives.py /path/to/cruise-trace-zips /path/to/output
```

Первый скрипт читает полные файлы `status-action-session*.txt/json`. Совпадающие имена TXT и JSON не считаются одной сессией: реальные даты часто разные. Второй строит индекс внешних членов ZIP и проверяет выбранные DIM/DLT-следы; он не объявляет вложенные двоичные форматы декодированными. Никакой скрипт из `tools/` не подключается к машине.

