# Native VHAL: проверяемый каталог прошивки Geely/ECARX

Дата анализа: 2026-09-04. Метод: исключительно статический разбор ELF; библиотеки не загружались, их машинный код не исполнялся, команд на автомобиль не отправлялось.

## Что доказано

В `vendor.ecarx.xma.automotive.vehicle_1.0-impl-lib.so` восстановлена полная таблица из **3532 vendor-конфигураций VehiclePropConfig**, регистрируемых конструктором `EcarxVehicleHalImplementation`, плюс одна отдельная стандартная конфигурация. Для каждой из 3532 получены ID, фактическая строка `configString`, тип по маске ID, access, changeMode, области, configArray, min/max частоты и скомпилированное начальное значение. Все 3532 ID уникальны; все имена найдены; неизвестных записей при статическом вычислении констант — 0.

| Показатель | Результат |
|---|---:|
| Vendor READ | 2563 |
| Vendor READ_WRITE | 969 |
| Vendor INT32 | 2668 |
| Vendor BYTES | 864 |
| Vendor ON_CHANGE | 3415 |
| Vendor STATIC | 117 |
| Vendor CONTINUOUS | 0 |
| Отдельная стандартная конфигурация | `0x11410A01`, INT32_VEC, WRITE, ON_CHANGE, initial `[1, 0]` |

`READ_WRITE` означает разрешенную запись на уровне данного VHAL-конфига. Это еще не доказательство, что установленный вариант ECU реализует соответствующую функцию, что приложение имеет доступ через Java/Binder, что исходящий конвертер поддерживает ID, и что конкретное значение будет принято автомобилем.

Скомпилированные `initialValue` — стартовые значения кэша. Часто это `-1`; нельзя считать их измерениями из автомобиля или допустимыми управляющими значениями. В нескольких BYTES-конфигурациях стартовый sentinel записан в int32Values — сохраняем это как есть, не исправляя прошивку по предположению.

## Первичные источники

Архив: `ecarx-hud-system-20260727-010640.zip`. SHA-256 `9bc62950e55910fc6eb59c99bf80439f7e7ac41f853b4c6c486977e14d062edd`. Полный архивный манифест: `../sources.json`.

| ELF | SHA-256 |
|---|---|
| `vendor.ecarx.xma.automotive.vehicle_1.0-impl-lib.so` | `f33e214a7102409febb40abe8c09ec960903fd869765c5db6940be015c703c85` |
| `android.hardware.automotive.vehicle_2.0-manager-lib.so` | `c26e55818e10a5c6ae21bfdd5ec4c341ebd5a12458bd5390433f23784f223892` |
| `vendor.ecarx.xma.automotive.vehicle_1.0-libproto-vendor-pa-native.so` | `871de6f162d081db3c53ff4fdd67e121821320054ca61170b5f99504ae1fc410` |
| `vhal_v1_0_net_impl-lib.so` | `b6feed82f777bfa8773c03b78c1f17038e122f492ef85126c095354a29c16756` |

Источник каждой строки таблицы: относительный путь ELF, хеш файла, адрес записи config, адрес инструкции записи prop/access, адрес строки имени и вызова конструктора строки в JSON. Адреса являются ELF virtual addresses без ASLR.

## Как восстановлена таблица и проверены права

1. `.init_array` содержит `0x1309CC`. Эта функция создает стандартный config `0x171040`, затем ветвится в `0x10EF4` (`b` по адресу `0x130A94`).
2. Инициализатор `0x10EF4–0x130980` заполняет vendor-таблицу начиная с `0x1710F0`, шаг `0xB0`, длина `0x97C40` / `0xB0` = 3532.
3. Конструктор `EcarxVehicleHalImplementation` регистрирует стандартный config по адресу `0x1386E8`, затем vendor-конфиги в цикле `0x138714–0x13876C`, через `VehiclePropertyStore::registerProperty`.
4. Сам `VehiclePropConfig` расположен в начале записи: prop `+0`, access `+4`, changeMode `+8`, areaConfigs `+0x10`, configArray `+0x20`, configString `+0x30`, min/max sample rate `+0x40/+0x44`. Остаток записи содержит default RawValue и карту default по областям.
5. В manager `checkReadPermission` (`0x10AB4`) читает байт `config+4` и проверяет **bit 0** (`tbnz w8,#0`). `checkWritePermission` (`0x10C50`) проверяет **bit 1**. Поэтому `1 = READ`, `2 = WRITE`, `3 = READ_WRITE` подтверждены кодом, а не именами полей.

Экстрактор `extract_static_vhal.py` — ограниченное распространение констант по ARM64-инструкциям. Он моделирует только запись констант, чтение .rodata, конструкторы hidl_string и выделение буфера для начального значения; один фиксированный цикл копирования 110 байт раскрыт статически. Неизвестные вызовы/инструкции останавливают извлечение. Скрипт не вызывает ELF через ctypes, dlopen или эмулятор.

## Приоритетные свойства

| ID VHAL | Имя в configString | Тип | Доступ |
|---|---|---|---|
| 0x214070F4 | AsyALatIndcr | INT32 | READ |
| 0x214070F5 | AsyALgtIndcr | INT32 | READ |
| 0x21407160 | TiGapSetForLgtCtrl | INT32 | READ |
| 0x21407705 | SteerWhlBtnPsd | INT32 | READ |
| 0x21407A7A | AdjSpdLimnSts | INT32 | READ |
| 0x21407A83 | CrsCtrlrSts | INT32 | READ |
| 0x21408000 | CB_ASY_ACCandTSR | INT32 | READ_WRITE |
| 0x21708207 | PA_Asy_ACCandTSR | BYTES | READ |
| 0x21407844 | HudDispActvReq | INT32 | READ_WRITE |
| 0x214078A7 | HudActvSts | INT32 | READ |
| 0x2140809A | CB_VF_HUD_ActvReq | INT32 | READ_WRITE |
| 0x2140809B | CB_VF_HUD_IllmnReq | INT32 | READ_WRITE |
| 0x2140809C | CB_VF_HUD_ErgoAdjmtReq | INT32 | READ_WRITE |
| 0x2140809D | CB_VF_HUD_ImgRotAdjmtReq | INT32 | READ_WRITE |
| 0x217082D1 | PA_VF_HUD_ActvSts | BYTES | READ |
| 0x217082D2 | PA_VF_HUD_IllmnReq | BYTES | READ |
| 0x217082D3 | PA_VF_HUD_ErgoAdjmtReq | BYTES | READ |
| 0x217082D4 | PA_VF_HUD_ImgRotAdjmtReq | BYTES | READ |
| 0x21407016 | PrkgDstCtrlSysSwt | INT32 | READ_WRITE |
| 0x21407143 | PrkgDstCtrlSts | INT32 | READ |
| 0x21407146 | PrkgImgDispReq | INT32 | READ |
| 0x217070E2 | SurrndgsObjDetnReqIdPen | BYTES | READ_WRITE |
| 0x2140715B | SurrndgsObjDetnResp | INT32 | READ |
| 0x21408200 | CB_SurrndgsObjDetnReq | INT32 | READ_WRITE |
| 0x21708493 | PA_SurrndgsObjDetnReq | BYTES | READ |
| 0x217070E6 | TopVisnDispExtnReqIdPen | BYTES | READ_WRITE |
| 0x21407161 | TopVisnDispExtnResp | INT32 | READ |
| 0x21408202 | CB_TopVisnDispExtnReq | INT32 | READ_WRITE |
| 0x21708495 | PA_TopVisnDispExtnReq | BYTES | READ |
| 0x214078EF | VehSpdIndcdVehSpdIndcd | INT32 | READ |
| 0x21407B38 | VehSpdLgtA | INT32 | READ |
| 0x21407A95 | EngSpdDispd | INT32 | READ |

Вывод по круизу и лимитеру: `CrsCtrlrSts`, `AdjSpdLimnSts`, `AsyALgtIndcr`, `TiGapSetForLgtCtrl` в этой прошивке являются **READ**. Их видимость в приборке или получение в Android не дает исходящую команду. `CB_ASY_ACCandTSR` — отдельный RW-кандидат, не равный установке скорости круиза; смысл payload должен подтверждаться callsite/конвертером и наблюдением штатного действия.

Вывод по HUD: запросы `CB_VF_HUD_*` и ответы `PA_VF_HUD_*` имеют разные ID и типы. Нельзя посылать назад BYTES из ответа PA, подразумевая, что это команда CB. Прошивка отдельно содержит запрос включения, яркость, ergonomics, вращение и статусы. Смысл значений и протокол кнопок нужно читать в транспортной сериализации и штатном клиенте.

Вывод по парковке: запросы/статусы также разделены. Например `PrkgDstCtrlSysSwt` RW, `PrkgDstCtrlSts` READ; `PrkgImgDispReq` READ. Отслеживание показа камеры/парктроника для паузы уведомлений должно опираться на реально наблюдаемый status/display flow, а не на последнее значение отправленного request.

## Дополнительные структуры protobuf

`protobuf_field_numbers.json` содержит **1084 номера полей в 179 generated protobuf message-классах**. Они извлечены из экспортированных `k...FieldNumber` и соответствующих 4-байтных констант. Это номера полей, не список значений enum. Wire type и допустимые значения не выдуманы по названию.

Практические примеры:

- `ProtoAccFusnTrfcReq`: `IdPen` tag 1, `OnOff1` tag 2.
- `ProtoSurrndgsObjDetnReq` и `ProtoTopVisnDispExtnReq`: `IdPen` tag 1, `OnOff1` tag 2.
- `Vfhudergoadjmt`: `Hudergoadjmt` tag 1, `Buttonpress` tag 2, `Buttonpress1` tag 3.
- `Vfimgrotadjmtreq`: `Imgrotadjmtreq` tag 1, `Buttonpress` tag 2, `Buttonpress1` tag 3.
- `ProtoHudAdjmtSwtSts`: `ErgoAdjmtActv` tag 1, `IllmnAdjmtActv` tag 2, `RotAdjmtActv` tag 3.
- `ProtoHudVisFctSetgReq`: 20 отдельных `HudFct00…19` tags 1…20 и `Pen` tag 21. Реальное назначение каждого Fct пока не доказано.

## Что читать следующим агентам

- `vhal_properties.json` — основной точный machine-каталог; `standalone_configs` учитывает отдельный стандартный ID.
- `vhal_properties.csv` — компактный поиск ID / имя / тип / права / changeMode.
- `selected_properties.json` — выборка приоритетных свойств без потери evidence.
- `protobuf_field_numbers.json` — структура generated protobuf по именам и тегам.
- `extract_static_vhal.py` — воспроизводимое извлечение точного источника.

При соединении с SDK необходимо использовать реальную таблицу Java PropertyIdTransformation; арифметический OR с маской VHAL не гарантирует корректность для исключений и PA/CB-пар. Перед реализацией записи нужны отдельные доказательства: SDK→VHAL mapping, поддерживаемый исходящий branch конвертера, формат/enum payload, штатные предусловия и независимый feedback.
