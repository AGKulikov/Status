#!/usr/bin/env python3
"""Offline constant propagation of a straight-line ELF C++ static initializer.
Never loads or executes ELF code. Calls to alloc/string constructors are modeled.
Requires pyelftools and capstone; exact source SHA256 included in output.
"""
from pathlib import Path
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from capstone.arm64_const import ARM64_OP_REG,ARM64_OP_IMM,ARM64_OP_MEM,ARM64_OP_FP
from collections import Counter
import struct,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'extracted/vendor-native/_vendor_lib64/vendor.ecarx.xma.automotive.vehicle_1.0-impl-lib.so'
OUT=Path(__file__).resolve().parent
fp=SRC.open('rb');elf=ELFFile(fp)
mem=bytearray(0x800000)
for s in elf.iter_sections():
 if s['sh_addr'] and s['sh_type']!='SHT_NOBITS':
  a=s['sh_addr']; mem[a:a+s['sh_size']]=s.data()
regs={'sp':0x7f0000}; provenance={};strings={};heap=0x400000;unknown=[];calls=Counter()
def rn(r):return md.reg_name(r)
def key(r):
 n=rn(r)
 if n in ('xzr','wzr'):return 'zero'
 if n[:1] in ('w','x'):return 'x'+n[1:]
 if n[:1] in ('s','d','q','v'):return 'v'+n[1:]
 return n
def width(r):
 n=rn(r)
 return 4 if n[:1] in ('w','s') else 16 if n[:1] in ('v','q') else 8

def readreg(r):
 k=key(r)
 if k=='zero':return 0
 v=regs.get(k)
 return None if v is None else v&((1<<(8*width(r)))-1)
def putreg(r,v):
 if key(r)!='zero':regs[key(r)]=None if v is None else v&((1<<(8*width(r)))-1)
def val(o):
 if o.type==ARM64_OP_REG:v=readreg(o.reg)
 elif o.type==ARM64_OP_IMM:v=o.imm
 elif o.type==ARM64_OP_FP:v=struct.unpack('<Q',struct.pack('<d',o.fp))[0]
 else:raise ValueError(o.type)
 if v is not None and o.shift.value:v<<=o.shift.value
 return v
def addr(o):
 b=readreg(o.mem.base);i=readreg(o.mem.index) if o.mem.index else 0
 return None if b is None or i is None else b+(i<<o.shift.value)+o.mem.disp

def rd(a,n):
 if a is None or not 0<=a<=len(mem)-n:return None
 return int.from_bytes(mem[a:a+n],'little')
def wr(a,n,v,pc):
 if a is not None and 0<=a<=len(mem)-n and v is not None:
  mem[a:a+n]=(v&((1<<(n*8))-1)).to_bytes(n,'little')
  for k in range(a,a+n):provenance[k]=pc
 elif a is not None and 0x1710f0<=a<0x208d30:unknown.append({'pc':hex(pc),'addr':hex(a),'length':n})

def cstr(a):
 if a is None:return None
 end=mem.find(b'\0',a)
 return mem[a:end].decode('utf-8',errors='replace')
md=Cs(CS_ARCH_ARM64,CS_MODE_ARM);md.detail=True
start=0x10ef4;end=0x130958
for i in md.disasm(bytes(mem[start:end]),start):
 o=i.operands;m=i.mnemonic
 if m in ('mov','adrp','movi'):
  putreg(o[0].reg,val(o[1]))
 elif m=='movk':
  prev=readreg(o[0].reg);n=val(o[1]);shift=o[1].shift.value
  putreg(o[0].reg,None if prev is None else (prev&~(0xffff<<shift))|n)
 elif m in ('add','sub'):
  a,b=val(o[1]),val(o[2]);putreg(o[0].reg,None if a is None or b is None else a+b if m=='add' else a-b)
 elif m.startswith(('str','stur')):
  n=1 if m.endswith('b') else 2 if m.endswith('h') else width(o[0].reg)
  a=addr(o[1]);wr(a,n,val(o[0]),i.address)
  if i.writeback:putreg(o[1].mem.base,a if len(o)==2 else readreg(o[1].mem.base)+val(o[2]))
 elif m.startswith(('ldr','ldur')):
  n=1 if m.endswith('b') else 2 if m.endswith('h') else width(o[0].reg)
  a=addr(o[1]);putreg(o[0].reg,rd(a,n))
  if i.writeback:putreg(o[1].mem.base,a if len(o)==2 else readreg(o[1].mem.base)+val(o[2]))
 elif m in ('stp','ldp'):
  n=width(o[0].reg);a=addr(o[2])
  if m=='stp':
   wr(a,n,val(o[0]),i.address);wr(None if a is None else a+n,n,val(o[1]),i.address)
  else:
   putreg(o[0].reg,rd(a,n));putreg(o[1].reg,rd(None if a is None else a+n,n))
  if i.writeback:putreg(o[2].mem.base,a if len(o)==3 else readreg(o[2].mem.base)+val(o[3]))
 elif m=='bl':
  dest=o[0].imm;calls[hex(dest)]+=1
  ret=None
  if dest==0xfd58:strings[regs.get('x0')]=dict(value=cstr(regs.get('x1')),source_string_va=hex(regs.get('x1')),constructor_call_va=hex(i.address))
  elif dest==0xf3e8:
   size=regs.get('x0');ret=heap;heap+=(size+15)&~15
  elif dest in (0xf708,0xf5e8):pass
  else:raise RuntimeError('unknown call '+hex(dest))
  for j in range(19):regs['x'+str(j)]=None
  for j in list(range(8))+list(range(16,32)):regs['v'+str(j)]=None
  regs['x0']=ret
 elif m in ('dup',):
  v=val(o[1]); putreg(o[0].reg,None if v is None else v|(v<<64))
 elif m=='cmp' and i.address==0x1082a4:pass
 elif m=='b.ne' and i.address==0x1082a8:
  # Exact fixed-length byte initializer loop, statically unrolled.
  assert regs['x8']==3
  for k in range(3,110):wr(regs['x11']+k,1,rd(regs['x9']+k,1),0x10829c)
  regs['x8']=110
 else:raise RuntimeError('unsupported '+m+' '+i.op_str)
props=[]
types={0x00100000:'STRING',0x00200000:'BOOLEAN',0x00400000:'INT32',0x00410000:'INT32_VEC',0x00500000:'INT64',0x00510000:'INT64_VEC',0x00600000:'FLOAT',0x00610000:'FLOAT_VEC',0x00700000:'BYTES',0x00e00000:'MIXED'}
access={0:'NONE',1:'READ',2:'WRITE',3:'READ_WRITE'}
changes={0:'STATIC',1:'ON_CHANGE',2:'CONTINUOUS'}
areas={0x01000000:'GLOBAL',0x03000000:'WINDOW',0x04000000:'MIRROR',0x05000000:'SEAT',0x06000000:'DOOR',0x07000000:'WHEEL'}
def vec(a,n,fmt):
 count=rd(a+8,4);p=rd(a,8)
 if count>2000:raise ValueError('bad length '+str(count))
 return [] if not count else list(struct.unpack('<'+str(count)+fmt,mem[p:p+count*n]))
for index in range(3532):
 a=0x1710f0+index*0xb0
 prop=rd(a,4);ac=rd(a+4,4);ch=rd(a+8,4)
 ss=strings.get(a+0x30,{})
 init={'int32Values':vec(a+0x48,4,'i'),'int64Values':vec(a+0x58,8,'q'),'floatValues':vec(a+0x68,4,'f'),'bytes':vec(a+0x78,1,'B')}
 ar=[]
 count=rd(a+0x18,4);ptr=rd(a+0x10,8)
 for j in range(count):
  q=ptr+j*40
  ar.append(dict(areaId=rd(q,4),minInt32Value=rd(q+4,4),maxInt32Value=rd(q+8,4),minInt64Value=rd(q+16,8),maxInt64Value=rd(q+24,8),minFloatValue=struct.unpack('<f',mem[q+32:q+36])[0],maxFloatValue=struct.unpack('<f',mem[q+36:q+40])[0]))
 props.append(dict(index=index,prop=prop,hex=f'0x{prop:08X}',configString=ss.get('value'),type=types.get(prop&0x00ff0000,'UNKNOWN'),type_mask_hex=f'0x{prop&0x00ff0000:08X}',area_category=areas.get(prop&0x0f000000,'UNKNOWN'),access=access.get(ac,'UNKNOWN'),access_raw=ac,changeMode=changes.get(ch,'UNKNOWN'),changeMode_raw=ch,areaConfigs=ar,configArray=vec(a+0x20,4,'i'),minSampleRate=struct.unpack('<f',mem[a+0x40:a+0x44])[0],maxSampleRate=struct.unpack('<f',mem[a+0x44:a+0x48])[0],initialValue=init,evidence=dict(config_va=hex(a),prop_access_store_va=hex(provenance[a]),**{k:v for k,v in ss.items() if k!='value'})))
result={'schema':'geely-native-vhal-static-config-v1','source':str(SRC.relative_to(ROOT)),'sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'method':'offline constant propagation of straight-line static initializer; binary never executed','initializer_va':[hex(start),hex(end)],'config_base_va':'0x1710f0','stride':176,'constructor_registration_loop_va':['0x138714','0x13876c'],'standalone_configs':[{'prop':289475073,'hex':'0x11410A01','configString':'','type':'INT32_VEC','access':'WRITE','access_raw':2,'changeMode':'ON_CHANGE','changeMode_raw':1,'initialValue':{'int32Values':[1,0]},'evidence':{'config_va':'0x171040','initializer_va':'0x1309cc','prop_access_literal_va':'0x159d58','prop_access_store_va':'0x130a08','initial_value_literal_va':'0x159d60','registration_va':'0x1386e8'}}],'properties':props,'unknown_stores':unknown,'modeled_calls':calls}
(OUT/'vhal_properties.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('properties',len(props),'strings',len(strings),'unknown stores',len(unknown),'heap',hex(heap),'access',Counter(x['access'] for x in props),'types',Counter(x['type'] for x in props),'changes',Counter(x['changeMode'] for x in props),'missing names',sum(not x['configString'] for x in props))
print(json.dumps(props[:4],ensure_ascii=False,indent=2))
