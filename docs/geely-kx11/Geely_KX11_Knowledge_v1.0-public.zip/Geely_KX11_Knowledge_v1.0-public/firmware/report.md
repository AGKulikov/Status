# ECARX KX11: системный каталог и правила использования

Дата анализа: 2026-09-04. Основание — статический разбор оригинальных файлов из `ecarx-hud-system-20260727-010640.zip`; исполняемые файлы автомобиля не запускались, подключений к автомобилю и отправки команд не было.

## Главное установленное

Получена проверяемая цепочка **3531 SDK ID → точная таблица штатного Java-сервиса → native VHAL property**. Это 2355 CarSignal ID и 1176 ID менеджеров CB/PA. Все 3531 ID уникальны, для каждого есть ровно одна запись направления в Java bridge, и все они найдены в native-конфигурации. Среди них 966 маршрутов записи и 2565 маршрутов чтения. Это характеристика скомпилированного интерфейса, а не 966 проверенных работающих действий автомобиля.

В native обнаружены 3532 vendor-конфигурации: **2563 READ, 969 READ_WRITE**, из них 2668 INT32 и 864 BYTES. Дополнительно зарегистрирована стандартная конфигурация `0x11410A01`, INT32_VEC, WRITE. Одно vendor-свойство `VgmRxSignals = 0x21707E00` отсутствует в Java-таблицах. Поэтому перечень native-свойств и перечень методов SDK закономерно не совпадают.

Обнаружена причина, способная ломать дальнейший reverse engineering: **759 совпадающих имён class+field имеют разные значения в разных копиях SDK внутри одного архива прошивки**. Например:

| Поле | System framework | Копия в DimMenu APK |
|---|---:|---:|
| `ECarXCarActivesafetyManager.ManagerId_paasyaccandtsr` | 33287 / `0x8207` | 33280 / `0x8200` |

Разные библиотеки внутри этого архива нельзя трактовать как разные версии автомобиля. Нельзя брать имя из одного SDK, числовой ID из второго и маршрут из третьего. Основной каталог выбирает один точный DEX-источник на класс и объединяет только совпадающее происхождение констант и тел методов. Для доступных классов framework является статическим справочником; это **не доказательство того, откуда класс загружается во время работы конкретного приложения**. Classloader/runtime origin необходимо устанавливать отдельно. Все варианты сохранены в `conflicts.json` и `constants.json`.

## Охват

| Результат | Количество | Файл |
|---|---:|---|
| Архивные файлы с размером и SHA-256 | 181 | `sources.json` |
| Уникальные константы class/name/type/value во всех архивных DEX | 16082 | `constants.json` |
| Конфликтующие class/name/type | 759 | `conflicts.json` |
| CarSignal ID | 2355 | `catalog.json → car_signals` |
| SDK manager CB/PA ID | 1176 | `catalog.json → manager_ids` |
| AdaptAPI function/sensor/config declarations | 909 | `catalog.json → adaptapi` |
| Android VehiclePropertyIds declarations | 115 | `catalog.json → android_vehicle_properties` |
| Native vendor-конфигурации | 3532 | `native/vhal_properties.json`, `catalog.json` |
| Java write/read bridges | 966 / 2565 | `sdk_to_hal.json` |
| Java protobuf/PA структуры | 188 | `schemas.json` |
| Native protobuf tags / сообщений | 1084 / 179 | `native/protobuf_field_numbers.json` |
| Подробно разобранные Adapt-функции кузова/сидений/света/безопасности/режимов/зеркал | 110 | `mapping/function_routes.json` |

Заявление «все константы» ограничено namespace-фильтрами автомобильного SDK, указанными в `extract_catalog.py`: это не все ресурсы UI, не все приватные внутренние функции каждого APK и не все CAN-фреймы ECU. Архив сам является выборочным экспортом, а не полным образом всех блоков автомобиля.

## Зафиксированная среда

Из `report.txt`:

- Модель `KX11`, device/product `kx11_high`; Android 9, API 28.
- Build `20.24.10.23024.41151`.
- Fingerprint `qti/kx11_high/kx11_high:9/20.24.10.23024.41151/539:userdebug/test-keys`.
- Security patch `2019-01-05`; ABI arm64-v8a, armeabi-v7a, armeabi.
- Основной физический экран 1920×720; в момент экспорта app area 1760×720. Это не геометрия HUD или DIM.
- Штатные `ecarx.settings` и `com.ecarx.dimmenu` имеют version code 20240314; настройки versionName `20240314-main`.
- `com.ecarx.sdk.openapi`: `4.1.5 (26A5CF0)` / 40525040.

`system_inventory.json` хранит build, версии, UID, requested permissions и экспортированные компоненты всех 12 выбранных пакетов, а также 17 init rc, feature XML и SOME/IP config. Большинство штатных сервисов работают под UID1000; AdaptApiTestApp и CarSignalTestApp в report имеют другие UID. Это не означает, что произвольному приложению достаточно имени пакета или exported=true для такого же доступа.

## Слои интерфейса

1. **AdaptAPI**: `ICarFunction` и интерфейсы модулей. `getFunctionValue`/`setFunctionValue` оперируют собственными function ID и Adapt enum. Есть проверки `isFunctionSupported`, `getSupportedFunctionZones`, `getSupportedFunctionValue`, watcher, float/customize-вариант. Само наличие generic setter не делает каждую функцию записываемой.
2. **CarSignal / CB / PA**: `CarSignalManager`, `ECarXCar…Manager`. Getter и setter подтверждены телом метода. CB обычно является командным вызовом, PA — структурой обратной связи; сохранены отдельные ID, payload type и enum validators.
3. **Java bridge**: `com.ecarx.car.hal.PropertyIdTransformation` в `packages/com.ecarx.car/base.apk`, `classes2.dex`. `mMgrtoHalPropIdMap` содержит 1932 ints / 966 пар; `mHaltoMgrPropIdMap` — 5130 ints / 2565 пар. Сохранены SHA payload и позиции. `SignalHalService` использует разные карты для set/get, а семь ARHUD transport-свойств обрабатываются специальной веткой. Общая формула `SDK_ID | mask` не заменяет эту таблицу.
4. **Native VHAL**: полное `prop`, тип, access и changeMode. Access восстановлен из зарегистрированной native-таблицы и подтвержден кодом `checkReadPermission`/`checkWritePermission`.
5. **Транспорт и ECU**: наличие VHAL записи еще не доказывает рабочий исходящий конвертер, наличие опции в комплектации, принятие значения ECU или выполнение физического действия. Для этого нужны следующие независимые доказательства.

**Не смешивать namespace:** Adapt ID ≠ SDK Signal/CB/PA ID ≠ VHAL ID ≠ QNX message/command ≠ CAN arbitration ID. Зоны и enum тоже принадлежат конкретному слою.

## Уточнения, влияющие на реализацию Natro

- `SignalHalService.getPropertyList()` в этой прошивке прямо возвращает `null`. Пустой результат такого API не является доказательством отсутствия сигналов.
- `SignalHalService.getProperty()` сначала возвращает запись из `mPropStore`; вызов HAL происходит только при отсутствии записи. Простое частое чтение SDK не гарантирует свежее измерение. Нужны подписка, timestamp поступления и контроль потери обновлений.
- `SignalHalService.setProperty()` использует write map; при неизвестном ID бросает `IllegalArgumentException`. Исключение от HAL в ветке записи логируется как `property not ready`. Отсутствие внешнего исключения не равно принятию действия ECU.
- Нативные `initialValue` — значения инициализации кэша, часто `-1`; это не данные реальной поездки и не разрешенные значения команд.
- Native ON_CHANGE/STATIC описывают публикацию свойств. В этой таблице нет CONTINUOUS; это не измерение реальной частоты CAN или задержки интерфейса.
- Найдена орфографическая разница SDK: `SignalId_LongitudinalSlop` и `getLongitudinalSlope()`. Обе стороны подтверждены одним literal 32258, поэтому связаны по доказательству, а не потеряны из-за несовпадения имени.
- Системный Binder публикуется под `ecarxcar_service`; `IECarXCarImpl.getCarService` маршрутизирует `car_signal`, `car_publicattribute`, `car_hardkey`, `car_info`, `car_sensor_tmp`, DVR service. Эти имена полезны для чтения архитектуры, но не являются отдельным разрешением на вызов.

Подробности неочевидных кузовных функций находятся в `mapping/report.md`:

- `BCM_FUNC_POWER_ONOFF` в рассматриваемой реализации идет в `CB_SS_Activation`; из названия нельзя выводить команду выключения автомобиля.
- `BCM_FUNC_DISPLAY_ONOFF`: значение0 запускает screensaver; значение1 в найденной ветке ничего не делает и возвращает SUCCEED.
- Поворотники и обычные двери в соответствующих Adapt-функциях подключены только на чтение, несмотря на `active` status.
- Настройка складывания зеркал не равна прямому управлению мотором.
- Положение боковых окон преобразуется между raw1…26 и процентами0…100 с шагом4; EX11 имеет отдельную ветку, которую нельзя переносить на KX11.
- Движение сиденья — направление и stop, а не абсолютная координата.
- Значения зон окон и сидений несовместимы. У функции без явно заданной зоны используется специальная default zone; нельзя автоматически заменять ее на0.

## Как использовать каталог перед новым изменением

Для любого запрошенного действия сначала открыть соответствующую Adapt-запись и реальное тело настройки. Зафиксировать точный source hash и source variant. Найти callback, связанные read/status PA, зоны и преобразование enum. Затем проверить SDK ID в `sdk_to_hal.json` и native type/access. Для BYTES читать реальную структуру сообщения и tag-поля: порядок Java fields не является wire order.

До утверждения «управление работает» нужны отдельные уровни подтверждения: скомпилированный маршрут, поддержка текущего варианта, принятая команда и независимый status/физическое действие. В цифровой инструкции эти статусы должны оставаться раздельными. `READ_WRITE`, `ApiResult.SUCCEED`, `FunctionStatus.active`, `exported=true` и видимость на приборке ни по отдельности, ни вместе не заменяют такую проверку.

Для неизвестного действия сначала анализировать архивы и пассивные записи штатного действия. Массовый перебор ID, enum или PA/CB payload на автомобиле не является способом заполнения пробелов каталога.

## Источники и воспроизводимость

Архив SHA-256: `9bc62950e55910fc6eb59c99bf80439f7e7ac41f853b4c6c486977e14d062edd`.

| Источник внутри архива | SHA-256 |
|---|---|
| `framework/system_framework/ecarx.adaptapi.jar` | `87a6fcf44f2a3a2dab7575d6e7a50396b980794074fd5fb5843162fbbde62ef0` |
| `framework/system_framework/ecarx.car.jar` | `57cb33a0af67c925cab0d1020dbdc9a226504455f46b8022b42313588a86a38b` |
| `packages/com.ecarx.car/base.apk` | `1cab337a3c056d6ba2a7a58f12638c2b7137f672a1613a2fb78305602c6683f3` |
| `packages/com.ecarx.dimmenu/base.apk` | `214193adbfd1f6ee9033c455b4f8f373fdfee95d89a12b3522f445a4ce647820` |
| `vendor-native/_vendor_lib64/vendor.ecarx.xma.automotive.vehicle_1.0-impl-lib.so` | `f33e214a7102409febb40abe8c09ec960903fd869765c5db6940be015c703c85` |

`sources.json` содержит полный манифест, в том числе одинаковые копии `/vendor` и `/system/vendor`. У каждой машинной записи есть member/DEX/class либо ELF offset. `method_evidence.json` и `service_evidence/` сохраняют bytecode. `mapping/` дополнительно содержит декомпиляцию и исходный дизассемблер. Воспроизводимое извлечение: `extract_catalog.py`, затем `native/extract_static_vhal.py`, затем `extract_bridge.py`; зависимостями являются androguard, pyelftools и capstone. Первичные архивы должны быть предоставлены отдельно по указанным хешам.
