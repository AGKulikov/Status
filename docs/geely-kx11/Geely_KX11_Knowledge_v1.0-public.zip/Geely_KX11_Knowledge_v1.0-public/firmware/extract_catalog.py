"""Read-only extraction of ECARX firmware SDK declarations and bytecode accessors."""
from pathlib import Path
import json,zipfile,hashlib,re,collections
from androguard.core.dex import DEX
from loguru import logger
logger.remove()
BASE=Path(__file__).resolve().parent
EX=BASE/'extracted'
manifest=json.loads((BASE/'sources.json').read_text())
hashes={x['path']:x['sha256'] for x in manifest['members']}

def dump(n,o): (BASE/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def src(p,dex):
 return {'member':p.relative_to(EX).as_posix(),'sha256':hashes[p.relative_to(EX).as_posix()],'dex_entry':dex}
def in_scope(cn):
 return cn.startswith(('Lcom/ecarx/xui/adaptapi/','Lecarx/car/','Landroid/car/','Lvendor/ecarx/xma/','Lecarx/dimprotocol/','Lecarx/powersomeip/'))
const={}; schemas={}; method_catalog={}; dc={}; sources_used=[]
files=sorted((EX/'framework').rglob('*.jar')) + sorted((EX/'packages').rglob('*.apk'))
for p in files:
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():
   if not re.match(r'classes\d*\.dex$',n):continue
   ss=src(p,n); sources_used.append(ss)
   d=DEX(z.read(n)); count=0
   for c in d.get_classes():
    cn=c.get_name()
    if not in_scope(cn):continue
    count+=1
    # First source is retained for method analysis, copies linked for declarations.
    if cn not in dc:dc[cn]=(d,c,ss)
    for f in c.get_fields():
     v=f.get_init_value()
     if v is None or 'static' not in f.get_access_flags_string():continue
     val=v.get_value()
     if not isinstance(val,(int,float,str,bool)):continue
     key=(cn,f.get_name(),f.get_descriptor(),repr(val))
     if key not in const:
      rec={'class':cn,'name':f.get_name(),'descriptor':f.get_descriptor(),'value':val,'flags':f.get_access_flags_string(),'value_provenance':'dex_encoded_static_value','sources':[]}
      if isinstance(val,int) and not isinstance(val,bool): rec['hex']=f'0x{val & 0xffffffff:08X}'
      const[key]=rec
     const[key]['sources'].append(ss)
    if '/nano/' in cn or 'PATypes$' in cn or 'CBTypes$' in cn:
     fields=[{'name':f.get_name(),'descriptor':f.get_descriptor(),'flags':f.get_access_flags_string()} for f in c.get_fields() if 'static' not in f.get_access_flags_string()]
     if fields and cn not in schemas: schemas[cn]={'class':cn,'fields':fields,'source':ss,'wire_layout':'not inferred from field order'}
    if cn.startswith(('Lcom/ecarx/xui/adaptapi/car/','Lecarx/car/hardware/')) and ('$' not in cn or cn.endswith('Listener;')):
     ms=[{'name':m.get_name(),'descriptor':m.get_descriptor(),'flags':m.get_access_flags_string()} for m in c.get_methods() if 'public' in m.get_access_flags_string() and not m.get_name().startswith('<')]
     if ms and cn not in method_catalog:method_catalog[cn]={'class':cn,'methods':ms,'source':ss}
   print(p.relative_to(EX),n,'classes',len(d.get_classes()),'in scope',count,flush=True)

constants=list(const.values())
dump('constants.json',{'scope':'Static primitive/string declarations from matching ECARX and Android car namespaces in every DEX in every archived APK/JAR. Declaration does not prove runtime availability.','constants':constants})
dump('schemas.json',list(schemas.values()))
dump('methods.json',list(method_catalog.values()))
by_class=collections.defaultdict(list)
conflicts=collections.defaultdict(list)
for x in constants:
 conflicts[(x['class'],x['name'],x['descriptor'])].append(x)
 # Method bodies MUST be paired only with constants from the same exact DEX.
 # System SDK is a source selection, not an assertion about runtime classloader precedence.
 chosen=dc.get(x['class'])
 if chosen and chosen[2] in x['sources']:by_class[x['class']].append(x)
dump('conflicts.json',{'meaning':'Same class and field name with differing embedded values across archived APK/JAR copies. Runtime classloader origin remains unverified. Never mix these declarations.','conflicts':[{'class':k[0],'name':k[1],'descriptor':k[2],'variants':v} for k,v in conflicts.items() if len(v)>1]})

# Full disassembly is retained only for SDK method classes, to support exact access/validator evidence.
def instruction_list(m):
 try:return [{'offset':i,'op':x.get_name(),'args':x.get_output()} for i,x in m.get_instructions_idx()]
 except Exception:return []

def analyze_method(cn,m,ss):
 ins=instruction_list(m)
 validators=[];operations=[]; literals=[]
 for i in ins:
  if '->isValid(' in i['args']:
   mt=re.search(r'(L[^;]+;)->isValid\(',i['args'])
   if mt: validators.append(mt.group(1))
  if 'Property(' in i['args'] or 'PropertyWithStatus(' in i['args']:operations.append(i)
  if i['op'].startswith('const'): literals.append(i)
 return {'name':m.get_name(),'descriptor':m.get_descriptor(),'validators':validators,'property_operations':operations,'literal_instructions':literals,'source':ss,'bytecode':ins}

signal_class='Lecarx/car/hardware/signal/CarSignalManager;'
d,c,ss=dc[signal_class]
methods={m.get_name():m for m in c.get_methods()}
signals=[]; evidence={}
for f in by_class[signal_class]:
 if not f['name'].startswith('SignalId_'):continue
 name=f['name'][len('SignalId_'):]
 access=[]; am=[]
 for prefix in ['get','set']:
  m=methods.get(prefix+name)
  if m is None and name=='LongitudinalSlop' and prefix=='get': m=methods.get('getLongitudinalSlope')
  if m:
   a=analyze_method(signal_class,m,ss); am.append({k:v for k,v in a.items() if k!='bytecode'})
   evidence[signal_class+'->'+m.get_name()+m.get_descriptor()]=a
   access.append('read' if prefix=='get' else 'write')
 r={'namespace':'ecarx.car.signal','name':name,'id':f['value'],'id_hex':f['hex'],'declaration':f,'sdk_access':access or ['no_matching_accessor'],'access_scope':'SDK method availability only; NOT native HAL access or runtime authorization','methods':am,'runtime_support':'unverified'}
 enums=[]
 for a in am:
  for vc in a['validators']:
   enums.append({'validator_class':vc,'constants':[{'name':v['name'],'value':v['value']} for v in by_class.get(vc,[]) if isinstance(v['value'],int)]})
 r['enum_validators']=enums
 signals.append(r)

managers=[]
for cn,(d,c,ss) in dc.items():
 if not cn.startswith('Lecarx/car/hardware/vehicle/ECarXCar') or not cn.endswith('Manager;'):continue
 methods={m.get_name():m for m in c.get_methods()}
 for f in by_class[cn]:
  if not f['name'].startswith('ManagerId_'):continue
  suffix=f['name'][len('ManagerId_'):].lower();am=[];access=[]
  for m in methods.values():
   mn=m.get_name(); norm=re.sub('[^a-z0-9]','',mn.lower())
   if norm==suffix or norm=='get'+suffix:
    a=analyze_method(cn,m,ss);am.append({k:v for k,v in a.items() if k!='bytecode'});evidence[cn+'->'+mn+m.get_descriptor()]=a
    if any('->set' in v['args'] for v in a['property_operations']):access.append('write')
    if any('->get' in v['args'] for v in a['property_operations']):access.append('read')
  managers.append({'namespace':'ecarx.car.manager','name':f['name'],'class':cn,'id':f['value'],'id_hex':f['hex'],'declaration':f,'sdk_access':sorted(set(access)) or ['unresolved'],'methods':am,'runtime_support':'unverified'})

adapt=[]
for f in [v for vs in by_class.values() for v in vs]:
 if not f['class'].startswith('Lcom/ecarx/xui/adaptapi/car/'):continue
 if not isinstance(f['value'],int):continue
 nm=f['name']
 if '_FUNC_' in nm or nm.startswith(('SENSOR_TYPE_','SENSOR_GROUP_TYPE_','CONFIG_INFO_','INFO_')):
  adapt.append({'namespace':'adaptapi','name':nm,'id':f['value'],'id_hex':f['hex'],'class':f['class'],'declaration':f,'sdk_access':'generic API exists; per-function mapping not inferred','runtime_support':'unverified','related_value_declarations':'constants.json (no name-prefix enum binding assumed)'})

vhal=[]
for f in by_class['Landroid/car/VehiclePropertyIds;']:
 if not isinstance(f['value'],int):continue
 n=f['value']; vhal.append({'namespace':'android.vehicle_property_id','name':f['name'],'id':n,'id_hex':f['hex'],'encoded_type_bits':f'0x{n & 0x00FF0000:08X}','encoded_area_bits':f'0x{n & 0x0F000000:08X}','encoded_group_bits':f'0x{n & 0xF0000000:08X}','declaration':f,'hal_access':'not present in ID encoding','runtime_support':'unverified'})

catalog={'schema_version':1,'scope':'One exact DEX source per class, preferring system framework declarations as static reference; runtime classloader precedence is NOT established. APK variants are separately recorded in conflicts.json. Not a live list of supported controls','source_archive_sha256':manifest['archive_sha256'],'critical_namespace_rule':'AdaptAPI function IDs, CarSignal IDs, manager CB/PA IDs, native VHAL property IDs, QNX message IDs and CAN arbitration IDs are different namespaces and MUST NOT be interchanged.','statistics':{'constants':len(constants),'signal_ids':len(signals),'manager_ids':len(managers),'adaptapi_entries':len(adapt),'android_vehicle_property_ids':len(vhal),'proto_or_pa_schemas':len(schemas)},'adaptapi':adapt,'car_signals':signals,'manager_ids':managers,'android_vehicle_properties':vhal}
dump('catalog.json',catalog)
dump('method_evidence.json',evidence)
dump('summary.json',{'statistics':catalog['statistics'],'signals_by_sdk_access':dict(collections.Counter('+'.join(r['sdk_access']) for r in signals)),'manager_ids_by_sdk_access':dict(collections.Counter('+'.join(r['sdk_access']) for r in managers)),'source_dexes':sources_used})
print(json.dumps(catalog['statistics']))
