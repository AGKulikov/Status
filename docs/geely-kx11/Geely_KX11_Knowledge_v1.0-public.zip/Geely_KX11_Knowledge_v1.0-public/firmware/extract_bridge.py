from pathlib import Path
import zipfile,json,struct,collections
from androguard.core.dex import DEX
from loguru import logger
logger.remove();b=Path(__file__).resolve().parent
manifest=json.loads((b/'sources.json').read_text());hashes={v['path']:v['sha256'] for v in manifest['members']}
member='packages/com.ecarx.car/base.apk'
with zipfile.ZipFile(b/'extracted'/member) as z:d=DEX(z.read('classes2.dex'))
cn='Lcom/ecarx/car/hal/PropertyIdTransformation;';c=d.get_class(cn)
a=[]
for m in c.get_methods():
 for off,i in m.get_instructions_idx():
  if i.get_name()=='fill-array-data-payload': a.append({'offset':off,'values':list(struct.unpack('<'+'I'*i.size,i.get_data())),'payload_sha256':__import__('hashlib').sha256(i.get_data()).hexdigest()})
# Validate pair layout against the actual create implementation; no firmware methods are executed.
c=d.get_class('Lcom/ecarx/car/hal/BidirectionalSparseIntArray;');lines=[]
for m in c.get_methods():
 lines.append('\nMETHOD '+m.get_name()+m.get_descriptor())
 for off,i in m.get_instructions_idx():lines.append(f'{off:06x} {i.get_name()} {i.get_output()}')
(b/'service_evidence/BidirectionalSparseIntArray.disasm.txt').write_text('\n'.join(lines))
x={'source':{'member':member,'sha256':hashes[member],'dex_entry':'classes2.dex','class':cn},'extraction':'DEX static integer arrays; original bytecode not executed','write_map':[],'read_map':[],'arhud_transfer_special_cases':[{'hal_prop':p,'hal_hex':f'0x{p:08X}'} for p in a[2]['values']]}
for label,arr in zip(['write_map','read_map'],a[:2]):
 vals=arr['values']
 for i in range(0,len(vals),2):
  x[label].append({'sdk_id':vals[i],'sdk_hex':f'0x{vals[i]:04X}','hal_prop':vals[i+1],'hal_hex':f'0x{vals[i+1]:08X}','payload_offset':f"0x{arr['offset']:X}",'array_pair_index':i//2})
(b/'sdk_to_hal.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
cat=json.loads((b/'catalog.json').read_text()); native=json.loads((b/'native/vhal_properties.json').read_text()); np={p['prop']:p for p in native['properties']}
lookup={key:{r['sdk_id']:r for r in x[key]} for key in ['write_map','read_map']}
for group in ['car_signals','manager_ids']:
 for r in cat[group]:
  refs=[]
  for key,idx in lookup.items():
   if r['id'] in idx:
    t=idx[r['id']];p=np.get(t['hal_prop']);refs.append({'direction':'write' if key=='write_map' else 'read','sdk_to_hal':t,'native_property':p,'runtime_application':'unverified'})
  r['native_routes']=refs
cat['native_properties']=native['properties'];cat['native_source']={k:v for k,v in native.items() if k!='properties'};cat['sdk_to_hal_source']=x['source'];cat['statistics']['native_properties']=len(np)
(b/'catalog.json').write_text(json.dumps(cat,ensure_ascii=False,indent=2))
summary={'write_pairs':len(x['write_map']),'read_pairs':len(x['read_map']),'native_configs':len(np),'mapped_hal_ids':len({v['hal_prop'] for k in lookup for v in lookup[k].values()}),'map_ids_absent_native':[r for k in lookup for r in lookup[k].values() if r['hal_prop'] not in np],'native_absent_maps':[p for p in np if p not in {v['hal_prop'] for k in lookup for v in lookup[k].values()}]}
(b/'bridge_summary.json').write_text(json.dumps(summary,indent=2));print(summary)
