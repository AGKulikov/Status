from loguru import logger
logger.remove()
from androguard.core.dex import DEX
from androguard.core.analysis.analysis import Analysis
from androguard.decompiler.decompiler import DecompilerDAD
import zipfile,pathlib,re,json,hashlib
r=pathlib.Path('/workspace/scratch/ed09f1994860/research/firmware_catalog');jar=r/'extracted/framework/system_framework/ecarx.adaptapi.jar';d=DEX(zipfile.ZipFile(jar).read('classes.dex'));a=Analysis(d);d.set_decompiler(DecompilerDAD(d,a));classes={c.get_name():c for c in d.get_classes()}
rows=[];evidence=[]
for c in d.get_classes():
 if not c.get_name().startswith('Lecarx/car/hardware/vehicle/ECarX'):continue
 for m in c.get_methods():
  if not m.get_name().startswith('CB_') or not m.get_code():continue
  regs={}; validators=[]; calls=[]
  for off,i in m.get_instructions_idx():
   out=i.get_output();name=i.get_name()
   if name.startswith('const') and not name.startswith(('const-string','const-class')):
    mt=re.match(r'(v\d+), (-?\d+)',out)
    if mt:regs[mt[1]]=int(mt[2])
   if '->isValid(' in out:validators.append(out.split(', ')[-1].split(';->')[0]+';')
   if '->setIntProperty(' in out or '->setFloatProperty(' in out or '->setProperty(' in out:
    fields=out.split(', ');calls.append({'callee':fields[-1], 'arguments':[regs.get(x,x) for x in fields[1:-1]]})
  if calls:
   en=[]
   for validator in validators:
    cl=classes.get(validator)
    if cl:
     try:
      src=cl.get_source();en.append({'class':validator,'source':src})
     except:pass
   row={'class':c.get_name(),'method':m.get_name(),'descriptor':m.get_descriptor(),'writes':calls,'validators':validators}
   rows.append(row)
   evidence.append('\nMETHOD '+c.get_name()+' '+m.get_name()+m.get_descriptor())
   evidence.extend(f'{off:05x} {i.get_name()} {i.get_output()}' for off,i in m.get_instructions_idx())
(r/'cb_command_routes.json').write_text(json.dumps({'source':str(jar.relative_to(r)),'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'warning':'Static command routing; not evidence of runtime hardware support or permission. Property command and feedback IDs differ.','routes':rows},indent=2))
(r/'mapping/CB_command_routes.disasm.txt').write_text('\n'.join(evidence))
# Extract compact mapping sections without claiming complete semantic resolution.
constants=json.loads((r/'mapping/constants_by_value.json').read_text());out=[]
for module in ['Bcm','Seat','DriveMode','Lamp','Safety','Vehicle']:
 p=r/'mapping'/f'{module}.annotated.java.txt';s=p.read_text()
 ms=list(re.finditer(r'VehicleFunction\.(intFunction|customFunction)\((\d+)',s))
 for idx,mt in enumerate(ms):
  block=s[mt.start():ms[idx+1].start() if idx+1<len(ms) else s.find('protected void onCarSignalConnected',mt.start())]
  function_id=int(mt[2]);names=[x.split('->')[-1] for x in constants.get(str(function_id),[]) if '/adaptapi/car/vehicle/I' in x and '$' not in x]
  callbacks=sorted(set(re.findall(r'onSetFunctionValue\(new [^/]*?/\*[^*]*Lecarx/car/hardware/vehicle/([A-Za-z0-9]+);->(CB_\w+)',block)))
  underlying=[r for r in rows if (r['class'].split('/')[-1].strip(';'),r['method']) in callbacks]
  out.append({'module':module,'function_id':function_id,'function_hex':hex(function_id),'names':sorted(set(names)),'kind':mt[1],'has_setter':'.onSetFunctionValue(' in block,'status_pa':[int(x) for x in re.findall(r'useStatusPAByIntBase\((\d+)',block)],'read_pa':[int(x) for x in re.findall(r'useValuePAByIntBase\((\d+)',block)],'read_signal':[int(x) for x in re.findall(r'useValueSignal\((\d+)',block)],'fixed_active':'.fixStatus(com.ecarx.xui.adaptapi.FunctionStatus.active)' in block,'model_overrides':sorted(set(re.findall(r'VehicleType\.(\w+)',block))),'callback_routes':underlying,'source_file':p.name,'evidence_excerpt':block})
(r/'mapping/function_routes.json').write_text(json.dumps({'warning':'Automatically grouped static buildFunctions evidence. Zone-specific associations and conversions must be read in evidence_excerpt. No live support asserted.','functions':out},ensure_ascii=False,indent=2))
print('CB routes',len(rows),'functions',len(out))
