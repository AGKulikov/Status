#!/usr/bin/env python3
"""Search this knowledge bundle offline. Prints evidence, never executes controls."""
import argparse,json
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('query');p.add_argument('--limit',type=int,default=12)
    args=p.parse_args();root=Path(__file__).resolve().parents[1];q=args.query.casefold();out=[]
    files=['firmware/catalog.json','controls/natro_controls.json','controls/mconfig_actions.json','controls/camera_route.json','display/key_functions.json','observations/observed_signals.json','firmware/conflicts.json','firmware/mapping/function_routes.json','open_questions.json']
    aliases={'климат':['hvac','temperature','fan'],'зеркал':['mirror','fold'],'круиз':['cruise','crsctrl','asylgt'],'лимитер':['limiter','limitation','spdlimn'],'подсвет':['ambient','ambli'],'камер':['camera','pac_activation'],'парк':['parking','prkg','pas_'],'двер':['door','lock'],'сиден':['seat']}
    queries=[q]+[x for k,v in aliases.items() if k in q for x in v]
    def walk(value,pointer='',parent=None):
        if isinstance(value,list):
            for i,x in enumerate(value):yield from walk(x,pointer+'/'+str(i))
        elif isinstance(value,dict):
            scalar={k:v for k,v in value.items() if not isinstance(v,(list,dict)) or (isinstance(v,list) and len(v)<20 and all(isinstance(x,(str,int,float,type(None))) for x in v))}
            searchable=json.dumps(scalar,ensure_ascii=False).casefold()
            if any(s in searchable for s in queries) and scalar:
                yield pointer,scalar
            else:
                for k,v in value.items():
                    if isinstance(v,(list,dict)):yield from walk(v,pointer+'/'+k,value)
    for f in files:
        path=root/f
        if not path.exists():continue
        for pointer,record in walk(json.loads(path.read_text())):
            out.append({'file':f,'json_pointer':pointer,'record':record})
    print(json.dumps({'query':args.query,'warning':'Static declarations and observed feedback are not authorization or proof of working writes. Check conflicts and full source fields before implementation.','match_count':len(out),'results':out[:max(1,args.limit)],'truncated':len(out)>args.limit},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
