#!/usr/bin/env python3
"""Read-only local ZIP inventory and DIM/DLT verification; no car access."""
import hashlib,json,re,sys,zipfile
from collections import Counter
from pathlib import Path

def main(root,out):
    dest=Path(out);dest.mkdir(parents=True,exist_ok=True)
    files=sorted(Path(root).glob('KX11-Cruise-Trace-*.zip'))
    records=[]; dim=[];dlt=[]
    for p in files:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
        members=[];texts=0;bytes_scanned=0;indicators=Counter()
        with zipfile.ZipFile(p) as z:
            for f in z.infolist():
                if f.is_dir() or f.filename.startswith('__MACOSX/'):continue
                members.append({'path':f.filename,'bytes':f.file_size,'zip_crc32':f'{f.CRC:08x}'})
                if not f.filename.endswith(('.txt','.log','.json','.cfg','.rc')):continue
                b=z.read(f);text=b.decode('utf-8',errors='replace');lines=text.splitlines();texts+=1;bytes_scanned+=len(b)
                for label,pattern in [('qconn',r'QCONN|qconn'),('capture_denied',r'Operation not permitted|permission to capture'),('cruise_symbols',r'DrvrCrs|AdjSpdLimnSts|CrsCtrlrSts'),('someip_error',r'someip error')]:
                    if re.search(pattern,text):indicators[label]+=1
                if p.name.endswith('112301.zip') and f.filename.endswith('logcat-full.txt'):
                    frames=Counter();before=Counter();after=Counter();pressed=False;marker=None;sample=[]
                    for n,l in enumerate(lines,1):
                        if 'DIM_PRESS_NOW__' in l:pressed=True;marker={'line':n,'text':l}
                        m=re.search(r'printUint8Array: crc32 \[\s*([^\]]+)\]',l)
                        if m:
                            frame=' '.join(m.group(1).split());frames[frame]+=1;(after if pressed else before)[frame]+=1
                            if len(sample)<2:sample.append({'line':n,'text':l})
                    dim.append({'archive':p.name,'path':f.filename,'source_sha256':hashlib.sha256(b).hexdigest(),'marker':marker,'rx_crc_input_frames_all':frames,'before_marker':before,'after_marker':after,'samples':sample,'scope':'CRC input buffer strings printed by HAL; this count is not tcpdump or complete kernel-frame count.'})
                if p.name.endswith('135239.zip') and (f.filename.endswith('qnx-bridge-export.txt') or 'qnx-mount-' in f.filename):
                    hits=[{'line':n,'text':l} for n,l in enumerate(lines,1) if re.search(r'CALLBACK|success|operation|mount|BRIDGE_EXIT|vdp|RESTORE',l,re.I)]
                    dlt.append({'archive':p.name,'path':f.filename,'source_sha256':hashlib.sha256(b).hexdigest(),'empty':not text.strip(),'evidence':hits})
        records.append({'archive':p.name,'bytes':p.stat().st_size,'sha256':h.hexdigest(),'members':members,'text_files_scanned':texts,'text_bytes_scanned':bytes_scanned,'indicator_file_counts':indicators,'analysis_depth':'Outer members inventoried; all outer text members scanned; DIM/DLT selected evidence verified. Nested binary logs/archives not fully decoded by this script.'})
    result={'archives':records,'dim_recheck':dim,'dlt_recheck':dlt}
    (dest/'trace_inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'archives':len(records),'outer_members':sum(len(x['members']) for x in records),'text_files_scanned':sum(x['text_files_scanned'] for x in records),'dim_cases':len(dim),'dlt_files':len(dlt)}))

if __name__=='__main__':main(*sys.argv[1:])
