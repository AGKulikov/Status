#!/usr/bin/env python3
"""Offline extraction of ECARX observations. Never connects to the car.
Usage: python3 analyze_action_logs.py INPUT_DIR OUTPUT_DIR
Counts are per export; TXT and JSON basenames are NOT assumed to be pairs.
"""
import sys, json, re, hashlib
from pathlib import Path
from collections import Counter

def events(path):
    if path.suffix == '.json':
        data=json.loads(path.read_text())
        for i,e in enumerate(data['events']):
            yield {'json_pointer':f'/events/{i}', 'sequence':e.get('sequence')}, e.get('timestamp'),e['event'],e.get('details',{})
    else:
        for i,line in enumerate(path.read_text().splitlines(),1):
            m=re.match(r'^(.*?)  #(\d+)  \[([^]]+)\]  (\S+)  (.*)$',line)
            if not m: raise ValueError(f'Unparsed line {path}:{i}')
            ts,seq,source,event,detail=m.groups()
            yield {'line':i,'sequence':int(seq)},ts,event,json.loads(detail)

def run(input_dir,output_dir):
    root=Path(input_dir); out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    sources=[]; signals={}; highlights=[]
    for p in sorted(root.glob('status-action-session*')):
        if p.suffix not in ['.txt','.json']:continue
        sha=hashlib.sha256(p.read_bytes()).hexdigest()
        per={}; counts=Counter(); first=None; last=None; session=None
        for loc,ts,event,d in events(p):
            counts[event]+=1
            first=ts if first is None else first;last=ts
            if event=='SESSION_START':session=d.get('session')
            if event.startswith('ECARX_ADAPTAPI_CAPABILITY') or event=='ECARX_ADAS_BINARY_BASELINE':
                highlights.append({'source':p.name,'locator':loc,'timestamp':ts,'event':event,'data':d})
            if event not in ['ECARX_ADAS_BASELINE','ECARX_ADAS_SIGNAL_CHANGE']:continue
            k=str(d['property_id']);a=per.setdefault(k,{'property_id':d['property_id'],'name':d.get('signal'),'baseline':None,'events':0,'changes':0,'values':Counter(),'samples':[]})
            a['events']+=1;a['values'][str(d.get('raw'))]+=1
            if event=='ECARX_ADAS_BASELINE':a['baseline']=d.get('raw')
            else:a['changes']+=1
            if len(a['samples'])<3:a['samples'].append({'locator':loc,'timestamp':ts,'raw':d.get('raw'),'decoded_by_recorder':d.get('decoded')})
        for k,a in per.items():
            g=signals.setdefault(k,{'signal_id':int(k),'names':[],'access':'not_established_by_observation','write_tested':False,'type':'integer observation; SDK type requires separate evidence','units':None,'observations':[]})
            if a['name'] not in g['names']:g['names'].append(a['name'])
            vals=list(a.pop('values').items())
            a['distinct_raw_count']=len(vals);a['raw_examples']=dict(vals[:16]);a['raw_examples_truncated']=len(vals)>16
            a['raw_minus_one_only']=len(vals)==1 and vals[0][0]=='-1'
            g['observations'].append({'source':p.name,**a})
        sources.append({'name':p.name,'sha256':sha,'size_bytes':p.stat().st_size,'session':session,'first_timestamp':first,'last_timestamp':last,'event_count':sum(counts.values()),'event_counts':counts,'numeric_signal_count':len(per),'changing_numeric_signals':sum(a['changes']>0 for a in per.values()),'raw_minus_one_only':sum(a['raw_minus_one_only'] for a in per.values())})
    result={'schema_version':1,'analysis_date':'2026-09-04','scope':'Observed numeric ECARX signals in 14 exports. Not a command allowlist. Integer -1 is not automatically interpreted for unknown types. Exports with matching basenames may have different dates. Counts across overlapping exports must not be added as independent trials.','sources':sources,'signals':sorted(signals.values(),key=lambda x:x['signal_id']),'capability_and_binary_evidence':highlights}
    (out/'observed_signals.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    rows=['# Наблюдения по журналам действий','', 'Это каталог зарегистрированных наблюдений, не список разрешённых команд. Совпадающие имена TXT/JSON не означают один сеанс.','', '| Экспорт | Сеанс | События | Числовые сигналы | Менялись | Только raw=-1 |','|---|---|---:|---:|---:|---:|']
    for s in sources:rows.append(f"| {s['name']} | {s['session']} | {s['event_count']} | {s['numeric_signal_count']} | {s['changing_numeric_signals']} | {s['raw_minus_one_only']} |")
    rows += ['',f"Различных SignalId во всех экспортах: **{len(signals)}**.", '', 'raw=-1 сохранён буквально. Его значение, единицы и допустимость требуют проверки конкретного типа; отсутствие изменений не доказывает отсутствие поддержки. Для каждой записи JSON содержит исходный SHA-256, строку либо JSON pointer и примеры значений.']
    (out/'observations.md').write_text('\n'.join(rows)+'\n')
    print(json.dumps({'exports':len(sources),'unique_signal_ids':len(signals),'output':str(out)}))

if __name__=='__main__':run(sys.argv[1],sys.argv[2])
