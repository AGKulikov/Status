import collections, datetime, hashlib, json, pathlib, socket, struct

def packets(path):
    data=path.read_bytes(); magic=data[:4]
    fmts={b'\xd4\xc3\xb2\xa1':('<',1e6),b'\xa1\xb2\xc3\xd4':('>',1e6),b'\x4d\x3c\xb2\xa1':('<',1e9),b'\xa1\xb2\x3c\x4d':('>',1e9)}
    endian,scale=fmts[magic]; link=struct.unpack_from(endian+'I',data,20)[0]; off=24; num=0
    while off+16<=len(data):
        sec,frac,cap,orig=struct.unpack_from(endian+'IIII',data,off);off+=16;raw=data[off:off+cap];off+=cap;num+=1
        if link==113:
            if raw[14:16]!=b'\x08\x00':continue
            raw=raw[16:]
        elif link==1:
            eth=struct.unpack_from('>H',raw,12)[0];eo=14
            while eth in [0x8100,0x88a8]:eth=struct.unpack_from('>H',raw,eo+2)[0];eo+=4
            if eth!=0x800:continue
            raw=raw[eo:]
        elif link not in [101,228]:continue
        if len(raw)<28 or raw[0]>>4!=4 or raw[9]!=17:continue
        ihl=(raw[0]&15)*4
        src=socket.inet_ntoa(raw[12:16]);dst=socket.inet_ntoa(raw[16:20]);sp,dp,ln,ck=struct.unpack_from('>HHHH',raw,ihl)
        payload=raw[ihl+8:ihl+ln]
        yield num,sec+frac/scale,src,sp,dst,dp,payload

def analyze(path):
    result={'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'udp_flows':{},'groups':{},'asdm_changes':[],'outbound_non_ack':[]}
    flows=collections.Counter();groups=collections.Counter();last=None;outs=collections.Counter()
    for num,ts,src,sp,dst,dp,p in packets(path):
        flows[f'{src}:{sp} -> {dst}:{dp}']+=1
        if len(p)<16:continue
        sv,me,ln=struct.unpack_from('>HHI',p)
        inbound=(src,sp,dst,dp)==('198.18.34.1',50500,'198.18.34.15',50335)
        outbound=(src,sp,dst,dp)==('198.18.34.15',50335,'198.18.34.1',50500)
        if inbound or outbound:groups[f'{"in" if inbound else "out"} {sv:04x}/{me:04x} len={len(p)}']+=1
        if inbound and (sv,me)==(0x1f,0x56) and len(p)>19:
            head=p[16:24].hex()
            if head!=last:
                result['asdm_changes'].append({'packet':num,'ts':ts,'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'head':head,'payload_offset2':p[18]})
                last=head
        if outbound and len(p)>16:outs[f'{sv:04x}/{me:04x} type={p[14]:02x} payload={p[16:].hex()}']+=1
    result['udp_flows']=dict(flows);result['groups']=dict(groups);result['outbound_non_ack']=dict(outs)
    return result

if __name__=='__main__':
    base=pathlib.Path(__file__).parent
    paths=[]
    for d in ['KX11-Cruise-Trace-20260809-093747','KX11-Cruise-Trace-20260809-101433','KX11-VP-Action-Evidence-20260815-190324_83890']:
        paths.extend((base/'extracted'/d).rglob('*.pcap'))
    results=[analyze(p) for p in paths]
    (base/'pcap_reanalysis.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    for r in results:
        print(r['file'].split('/extracted/')[-1],r['asdm_changes'],r['outbound_non_ack'])
